
-- Add service and campaign_status to admin_clients
ALTER TABLE public.admin_clients
  ADD COLUMN service TEXT NOT NULL DEFAULT 'Motor de Leads',
  ADD COLUMN campaign_status TEXT NOT NULL DEFAULT 'Ativa';

-- Performance metrics table (per client, per period)
CREATE TABLE public.admin_performance_metrics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID REFERENCES public.admin_clients(id) ON DELETE CASCADE NOT NULL,
  period_date DATE NOT NULL DEFAULT CURRENT_DATE,
  leads_generated INTEGER NOT NULL DEFAULT 0,
  ad_spend NUMERIC(12,2) NOT NULL DEFAULT 0,
  conversions INTEGER NOT NULL DEFAULT 0,
  revenue_generated NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_performance_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view metrics"
ON public.admin_performance_metrics FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated can insert metrics"
ON public.admin_performance_metrics FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated can update metrics"
ON public.admin_performance_metrics FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Authenticated can delete metrics"
ON public.admin_performance_metrics FOR DELETE TO authenticated USING (true);

-- Seed service data for existing clients
UPDATE public.admin_clients SET service = 'Motor de Leads + DNA Digital', campaign_status = 'Ativa' WHERE name = 'RM Incorporadora';
UPDATE public.admin_clients SET service = 'Imersão Visual + Piloto Automático', campaign_status = 'Ativa' WHERE name = 'Assis Imóveis de Luxo';
UPDATE public.admin_clients SET service = 'Motor de Leads + Cérebro Digital', campaign_status = 'Ativa' WHERE name = 'Braga & Oliveira';
UPDATE public.admin_clients SET service = 'DNA Digital + Vitrine Impactante', campaign_status = 'Pausada' WHERE name = 'Serra Garden Empreendimentos';
UPDATE public.admin_clients SET service = 'Imersão Visual + Motor de Leads', campaign_status = 'Ativa' WHERE name = 'Palazzo Construtora';

-- Seed performance metrics (last 30 days sample)
INSERT INTO public.admin_performance_metrics (client_id, period_date, leads_generated, ad_spend, conversions, revenue_generated)
SELECT id, CURRENT_DATE - 1, 45, 2800.00, 12, 38000.00 FROM public.admin_clients WHERE name = 'RM Incorporadora'
UNION ALL
SELECT id, CURRENT_DATE - 7, 38, 2500.00, 9, 32000.00 FROM public.admin_clients WHERE name = 'RM Incorporadora'
UNION ALL
SELECT id, CURRENT_DATE - 1, 62, 4200.00, 18, 85000.00 FROM public.admin_clients WHERE name = 'Assis Imóveis de Luxo'
UNION ALL
SELECT id, CURRENT_DATE - 7, 55, 3800.00, 15, 72000.00 FROM public.admin_clients WHERE name = 'Assis Imóveis de Luxo'
UNION ALL
SELECT id, CURRENT_DATE - 1, 33, 1900.00, 8, 24000.00 FROM public.admin_clients WHERE name = 'Braga & Oliveira'
UNION ALL
SELECT id, CURRENT_DATE - 7, 28, 1700.00, 6, 19000.00 FROM public.admin_clients WHERE name = 'Braga & Oliveira'
UNION ALL
SELECT id, CURRENT_DATE - 1, 18, 1200.00, 4, 12000.00 FROM public.admin_clients WHERE name = 'Palazzo Construtora'
UNION ALL
SELECT id, CURRENT_DATE - 7, 15, 1100.00, 3, 9500.00 FROM public.admin_clients WHERE name = 'Palazzo Construtora';
