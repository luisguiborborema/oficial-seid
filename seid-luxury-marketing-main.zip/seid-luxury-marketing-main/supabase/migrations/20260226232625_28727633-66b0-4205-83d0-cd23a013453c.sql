
-- Pipeline Comercial: leads from diagnostic form
CREATE TABLE public.admin_pipeline_leads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  company TEXT,
  source TEXT DEFAULT 'Diagnóstico Site',
  status TEXT NOT NULL DEFAULT 'Novo',
  priority TEXT NOT NULL DEFAULT 'P2',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_pipeline_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Auth can view pipeline" ON public.admin_pipeline_leads FOR SELECT USING (true);
CREATE POLICY "Auth can insert pipeline" ON public.admin_pipeline_leads FOR INSERT WITH CHECK (true);
CREATE POLICY "Auth can update pipeline" ON public.admin_pipeline_leads FOR UPDATE USING (true);
CREATE POLICY "Auth can delete pipeline" ON public.admin_pipeline_leads FOR DELETE USING (true);

CREATE TRIGGER update_pipeline_updated_at BEFORE UPDATE ON public.admin_pipeline_leads
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Gestão de Capacidade: deliverables/projects
CREATE TABLE public.admin_deliverables (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  client_name TEXT,
  type TEXT NOT NULL DEFAULT 'Vídeo',
  status TEXT NOT NULL DEFAULT 'Em Produção',
  due_date DATE,
  assignee TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_deliverables ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Auth can view deliverables" ON public.admin_deliverables FOR SELECT USING (true);
CREATE POLICY "Auth can insert deliverables" ON public.admin_deliverables FOR INSERT WITH CHECK (true);
CREATE POLICY "Auth can update deliverables" ON public.admin_deliverables FOR UPDATE USING (true);
CREATE POLICY "Auth can delete deliverables" ON public.admin_deliverables FOR DELETE USING (true);

CREATE TRIGGER update_deliverables_updated_at BEFORE UPDATE ON public.admin_deliverables
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Repositório de Ativos: quick links
CREATE TABLE public.admin_assets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  label TEXT NOT NULL,
  url TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Geral',
  icon TEXT DEFAULT 'link',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_assets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Auth can view assets" ON public.admin_assets FOR SELECT USING (true);
CREATE POLICY "Auth can insert assets" ON public.admin_assets FOR INSERT WITH CHECK (true);
CREATE POLICY "Auth can update assets" ON public.admin_assets FOR UPDATE USING (true);
CREATE POLICY "Auth can delete assets" ON public.admin_assets FOR DELETE USING (true);
