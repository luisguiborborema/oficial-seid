
-- Clients table
CREATE TABLE public.admin_clients (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Ativo',
  next_billing DATE,
  drive_link TEXT,
  monthly_value NUMERIC(12,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_clients ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only authenticated users can view clients"
ON public.admin_clients FOR SELECT TO authenticated USING (true);

CREATE POLICY "Only authenticated users can insert clients"
ON public.admin_clients FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Only authenticated users can update clients"
ON public.admin_clients FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Only authenticated users can delete clients"
ON public.admin_clients FOR DELETE TO authenticated USING (true);

-- Financial KPIs table
CREATE TABLE public.admin_financial_kpis (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  month TEXT NOT NULL,
  mrr NUMERIC(12,2) DEFAULT 0,
  revenue_oneoff NUMERIC(12,2) DEFAULT 0,
  operational_costs NUMERIC(12,2) DEFAULT 0,
  investments NUMERIC(12,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(month)
);

ALTER TABLE public.admin_financial_kpis ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only authenticated users can view kpis"
ON public.admin_financial_kpis FOR SELECT TO authenticated USING (true);

CREATE POLICY "Only authenticated users can insert kpis"
ON public.admin_financial_kpis FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Only authenticated users can update kpis"
ON public.admin_financial_kpis FOR UPDATE TO authenticated USING (true);

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_admin_clients_updated_at
BEFORE UPDATE ON public.admin_clients
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_admin_financial_kpis_updated_at
BEFORE UPDATE ON public.admin_financial_kpis
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample data
INSERT INTO public.admin_financial_kpis (month, mrr, revenue_oneoff, operational_costs, investments) VALUES
('2026-02', 45000.00, 12500.00, 18700.00, 8500.00);

INSERT INTO public.admin_clients (name, status, next_billing, drive_link, monthly_value) VALUES
('RM Incorporadora', 'Ativo', '2026-03-15', '#', 8500.00),
('Assis Imóveis de Luxo', 'Ativo', '2026-03-10', '#', 12000.00),
('Braga & Oliveira', 'Ativo', '2026-03-20', '#', 9500.00),
('Serra Garden Empreendimentos', 'Em onboarding', '2026-04-01', '#', 7500.00),
('Palazzo Construtora', 'Ativo', '2026-03-05', '#', 7500.00);
