
-- SOPs / Manual de Operações
CREATE TABLE public.admin_sops (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Geral',
  url TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_sops ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth can view sops" ON public.admin_sops FOR SELECT USING (true);
CREATE POLICY "Auth can insert sops" ON public.admin_sops FOR INSERT WITH CHECK (true);
CREATE POLICY "Auth can update sops" ON public.admin_sops FOR UPDATE USING (true);
CREATE POLICY "Auth can delete sops" ON public.admin_sops FOR DELETE USING (true);

-- Radar de Benchmarking
CREATE TABLE public.admin_benchmarks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Criativo',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_benchmarks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth can view benchmarks" ON public.admin_benchmarks FOR SELECT USING (true);
CREATE POLICY "Auth can insert benchmarks" ON public.admin_benchmarks FOR INSERT WITH CHECK (true);
CREATE POLICY "Auth can update benchmarks" ON public.admin_benchmarks FOR UPDATE USING (true);
CREATE POLICY "Auth can delete benchmarks" ON public.admin_benchmarks FOR DELETE USING (true);

-- CRM Pós-Venda: last check-in per client
ALTER TABLE public.admin_clients ADD COLUMN IF NOT EXISTS last_checkin DATE;
