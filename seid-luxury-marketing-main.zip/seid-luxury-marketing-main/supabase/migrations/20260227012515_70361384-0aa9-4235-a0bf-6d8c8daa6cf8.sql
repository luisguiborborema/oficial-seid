
-- Table to link authenticated users to their client profile
CREATE TABLE public.client_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES public.admin_clients(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE public.client_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.client_profiles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Table for client files/assets
CREATE TABLE public.client_files (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.admin_clients(id) ON DELETE CASCADE,
  category TEXT NOT NULL DEFAULT 'Criativos',
  label TEXT NOT NULL,
  url TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.client_files ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clients can view own files" ON public.client_files
  FOR SELECT TO authenticated USING (
    client_id IN (SELECT client_id FROM public.client_profiles WHERE user_id = auth.uid())
  );

-- Admin can manage client files
CREATE POLICY "Auth can insert client files" ON public.client_files
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Auth can update client files" ON public.client_files
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Auth can delete client files" ON public.client_files
  FOR DELETE TO authenticated USING (true);

-- Table for automation status
CREATE TABLE public.client_automations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.admin_clients(id) ON DELETE CASCADE,
  automation_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Ativa',
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.client_automations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clients can view own automations" ON public.client_automations
  FOR SELECT TO authenticated USING (
    client_id IN (SELECT client_id FROM public.client_profiles WHERE user_id = auth.uid())
  );

CREATE POLICY "Auth can insert automations" ON public.client_automations
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Auth can update automations" ON public.client_automations
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Auth can delete automations" ON public.client_automations
  FOR DELETE TO authenticated USING (true);

-- Add looker_studio_url to admin_clients for per-client report embedding
ALTER TABLE public.admin_clients ADD COLUMN IF NOT EXISTS looker_studio_url TEXT;

-- Allow clients to view their own client record
CREATE POLICY "Clients can view own client data" ON public.admin_clients
  FOR SELECT TO authenticated USING (
    id IN (SELECT client_id FROM public.client_profiles WHERE user_id = auth.uid())
  );

-- Allow clients to view their own performance metrics
CREATE POLICY "Clients can view own metrics" ON public.admin_performance_metrics
  FOR SELECT TO authenticated USING (
    client_id IN (SELECT client_id FROM public.client_profiles WHERE user_id = auth.uid())
  );
