import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import logoSeid from "@/assets/logo-seid.png";
import {
  LayoutDashboard,
  Users,
  DollarSign,
  Bot,
  LogOut,
  ExternalLink,
  TrendingUp,
  TrendingDown,
  Wallet,
  BarChart3,
  Gauge,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Pencil,
  Target,
  Percent,
  Zap,
  AlertTriangle,
  Kanban,
  CalendarCheck,
  FolderOpen,
  FileText,
  Video,
  Globe,
  Link2,
  Clock,
  ChevronRight,
  Shield,
  BookOpen,
  KeyRound,
  UserPlus,
  Trash2,
  Plus,
  RotateCcw,
  CheckCircle,
  Eye,
  Phone,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  LineChart,
  Line,
} from "recharts";

type Tab = "overview" | "cockpit" | "clients" | "financial" | "governance" | "access" | "ai";
type CockpitSubTab = "performance" | "alerts" | "pipeline" | "capacity" | "assets";

interface Client {
  id: string;
  name: string;
  status: string;
  next_billing: string | null;
  drive_link: string | null;
  monthly_value: number | null;
  service: string;
  campaign_status: string;
  last_checkin: string | null;
}

interface SOP {
  id: string;
  title: string;
  category: string;
  url: string | null;
  description: string | null;
}

interface Benchmark {
  id: string;
  title: string;
  url: string;
  category: string;
  notes: string | null;
  created_at: string;
}

interface KPI {
  mrr: number;
  revenue_oneoff: number;
  operational_costs: number;
  investments: number;
}

interface PerfMetric {
  id: string;
  client_id: string;
  period_date: string;
  leads_generated: number;
  ad_spend: number;
  conversions: number;
  revenue_generated: number;
}

interface PipelineLead {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  company: string | null;
  source: string | null;
  status: string;
  priority: string;
  notes: string | null;
  created_at: string;
}

interface Deliverable {
  id: string;
  title: string;
  client_name: string | null;
  type: string;
  status: string;
  due_date: string | null;
  assignee: string | null;
}

interface Asset {
  id: string;
  label: string;
  url: string;
  category: string;
  icon: string | null;
}

type PeriodFilter = "today" | "7days" | "month";

const tabs: { key: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { key: "overview", label: "Visão Geral", icon: LayoutDashboard },
  { key: "cockpit", label: "Cockpit", icon: Gauge },
  { key: "clients", label: "Clientes", icon: Users },
  { key: "financial", label: "Financeiro", icon: DollarSign },
  { key: "governance", label: "Governança", icon: Shield },
  { key: "access", label: "Acessos", icon: KeyRound },
  { key: "ai", label: "IA / Automações", icon: Bot },
];

const cockpitSubTabs: { key: CockpitSubTab; label: string; icon: typeof Gauge }[] = [
  { key: "performance", label: "Performance", icon: Gauge },
  { key: "alerts", label: "Radar de Alertas", icon: AlertTriangle },
  { key: "pipeline", label: "Pipeline", icon: Kanban },
  { key: "capacity", label: "Capacidade", icon: CalendarCheck },
  { key: "assets", label: "Ativos", icon: FolderOpen },
];

const formatCurrency = (v: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);

const TrendIcon = ({ value, prev }: { value: number; prev: number }) => {
  if (value > prev) return <ArrowUpRight className="w-3.5 h-3.5 text-green-400" />;
  if (value < prev) return <ArrowDownRight className="w-3.5 h-3.5 text-red-400/70" />;
  return <Minus className="w-3.5 h-3.5 text-gold/50" />;
};

const priorityColor: Record<string, string> = {
  P1: "bg-red-500/15 text-red-400",
  P2: "bg-gold/15 text-gold",
  P3: "bg-champagne/10 text-champagne/50",
};

const pipelineStatusColor: Record<string, string> = {
  Novo: "bg-blue-500/15 text-blue-400",
  Qualificado: "bg-gold/15 text-gold",
  "Em Negociação": "bg-champagne/15 text-champagne/70",
  Convertido: "bg-green-500/15 text-green-400",
  Perdido: "bg-red-500/10 text-red-400/50",
};

const deliverableStatusColor: Record<string, string> = {
  "Em Produção": "bg-gold/15 text-gold",
  "Revisão": "bg-blue-500/15 text-blue-400",
  "Aprovado": "bg-green-500/15 text-green-400",
  "Entregue": "bg-champagne/10 text-champagne/50",
  "Atrasado": "bg-red-500/15 text-red-400",
};

const deliverableTypeIcon: Record<string, typeof Video> = {
  Vídeo: Video,
  Site: Globe,
  "Landing Page": Globe,
  Criativo: FileText,
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [cockpitSubTab, setCockpitSubTab] = useState<CockpitSubTab>("performance");
  const [clients, setClients] = useState<Client[]>([]);
  const [kpi, setKpi] = useState<KPI>({ mrr: 0, revenue_oneoff: 0, operational_costs: 0, investments: 0 });
  const [metrics, setMetrics] = useState<PerfMetric[]>([]);
  const [pipelineLeads, setPipelineLeads] = useState<PipelineLead[]>([]);
  const [deliverables, setDeliverables] = useState<Deliverable[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [sops, setSops] = useState<SOP[]>([]);
  const [benchmarks, setBenchmarks] = useState<Benchmark[]>([]);
  const [loading, setLoading] = useState(true);
  const [periodFilter, setPeriodFilter] = useState<PeriodFilter>("month");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Access management state
  const [accessProfiles, setAccessProfiles] = useState<{ user_id: string; client_id: string; email: string }[]>([]);
  const [accessFormClient, setAccessFormClient] = useState("");
  const [accessFormEmail, setAccessFormEmail] = useState("");
  const [accessFormPassword, setAccessFormPassword] = useState("");
  const [accessLoading, setAccessLoading] = useState(false);
  const [accessMsg, setAccessMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [resetPasswordUserId, setResetPasswordUserId] = useState<string | null>(null);
  const [resetPasswordValue, setResetPasswordValue] = useState("");

  // Client files management state
  const [clientFiles, setClientFiles] = useState<{ id: string; client_id: string; label: string; url: string; category: string }[]>([]);
  const [fileFormClient, setFileFormClient] = useState("");
  const [fileFormLabel, setFileFormLabel] = useState("");
  const [fileFormUrl, setFileFormUrl] = useState("");
  const [fileFormCategory, setFileFormCategory] = useState("Criativos");
  const [fileLoading, setFileLoading] = useState(false);
  const [fileMsg, setFileMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [editFileLabel, setEditFileLabel] = useState("");
  const [editFileUrl, setEditFileUrl] = useState("");
  const [editFileCategory, setEditFileCategory] = useState("");
  const [filterFileClient, setFilterFileClient] = useState("");
  const [filterFileCategory, setFilterFileCategory] = useState("");
  const filteredClientFiles = clientFiles.filter((f) => {
    if (filterFileClient && f.client_id !== filterFileClient) return false;
    if (filterFileCategory && f.category !== filterFileCategory) return false;
    return true;
  });

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/admin-seid/login");
        return;
      }
      const [clientsRes, kpiRes, metricsRes, pipelineRes, deliverablesRes, assetsRes, sopsRes, benchmarksRes, clientFilesRes] = await Promise.all([
        supabase.from("admin_clients").select("*").order("name"),
        supabase.from("admin_financial_kpis").select("*").order("month", { ascending: false }).limit(1),
        supabase.from("admin_performance_metrics").select("*").order("period_date", { ascending: false }),
        supabase.from("admin_pipeline_leads").select("*").order("created_at", { ascending: false }),
        supabase.from("admin_deliverables").select("*").order("due_date", { ascending: true }),
        supabase.from("admin_assets").select("*").order("category"),
        supabase.from("admin_sops").select("*").order("category"),
        supabase.from("admin_benchmarks").select("*").order("created_at", { ascending: false }),
        supabase.from("client_files").select("*").order("created_at", { ascending: false }),
      ]);
      if (clientsRes.data) setClients(clientsRes.data as Client[]);
      if (kpiRes.data && kpiRes.data.length > 0) {
        const k = kpiRes.data[0];
        setKpi({
          mrr: Number(k.mrr) || 0,
          revenue_oneoff: Number(k.revenue_oneoff) || 0,
          operational_costs: Number(k.operational_costs) || 0,
          investments: Number(k.investments) || 0,
        });
      }
      if (metricsRes.data) setMetrics(metricsRes.data as PerfMetric[]);
      if (pipelineRes.data) setPipelineLeads(pipelineRes.data as PipelineLead[]);
      if (deliverablesRes.data) setDeliverables(deliverablesRes.data as Deliverable[]);
      if (assetsRes.data) setAssets(assetsRes.data as Asset[]);
      if (sopsRes.data) setSops(sopsRes.data as SOP[]);
      if (benchmarksRes.data) setBenchmarks(benchmarksRes.data as Benchmark[]);
      if (clientFilesRes.data) setClientFiles(clientFilesRes.data as any[]);
      setLoading(false);
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) navigate("/admin-seid/login");
    });

    checkAuth();
    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/admin-seid/login");
  };

  const loadAccessProfiles = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-client-user`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ action: "list" }),
    });
    const data = await res.json();
    if (data.profiles) setAccessProfiles(data.profiles);
  };

  const handleCreateClientUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setAccessLoading(true);
    setAccessMsg(null);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-client-user`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ action: "create", email: accessFormEmail, password: accessFormPassword, client_id: accessFormClient }),
    });
    const data = await res.json();
    setAccessLoading(false);
    if (data.success) {
      setAccessMsg({ type: "success", text: `Acesso criado com sucesso! O e-mail ${accessFormEmail} foi vinculado ao cliente via RLS.` });
      setAccessFormEmail("");
      setAccessFormPassword("");
      setAccessFormClient("");
      loadAccessProfiles();
    } else {
      setAccessMsg({ type: "error", text: data.error || "Erro ao criar acesso." });
    }
  };

  const handleResetPassword = async (userId: string) => {
    if (!resetPasswordValue) return;
    setAccessLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-client-user`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ action: "reset_password", user_id: userId, password: resetPasswordValue }),
    });
    const data = await res.json();
    setAccessLoading(false);
    setResetPasswordUserId(null);
    setResetPasswordValue("");
    setAccessMsg(data.success ? { type: "success", text: "Senha resetada com sucesso." } : { type: "error", text: data.error || "Erro." });
  };

  const handleDeleteAccess = async (userId: string) => {
    if (!confirm("Remover acesso deste cliente? Esta ação é irreversível.")) return;
    setAccessLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-client-user`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ action: "delete", user_id: userId }),
    });
    const data = await res.json();
    setAccessLoading(false);
    if (data.success) {
      setAccessMsg({ type: "success", text: "Acesso removido." });
      loadAccessProfiles();
    } else {
      setAccessMsg({ type: "error", text: data.error || "Erro." });
    }
  };

  // Load access profiles when tab is selected
  useEffect(() => {
    if (activeTab === "access") loadAccessProfiles();
  }, [activeTab]);

  // Filter metrics by period
  const filteredMetrics = useMemo(() => {
    const now = new Date();
    return metrics.filter((m) => {
      const d = new Date(m.period_date);
      if (periodFilter === "today") return d.toDateString() === now.toDateString();
      if (periodFilter === "7days") return (now.getTime() - d.getTime()) / 86400000 <= 7;
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    });
  }, [metrics, periodFilter]);

  // Aggregate cockpit KPIs
  const cockpitKPIs = useMemo(() => {
    const totalLeads = filteredMetrics.reduce((s, m) => s + m.leads_generated, 0);
    const totalSpend = filteredMetrics.reduce((s, m) => s + Number(m.ad_spend), 0);
    const totalConversions = filteredMetrics.reduce((s, m) => s + m.conversions, 0);
    const totalRevenue = filteredMetrics.reduce((s, m) => s + Number(m.revenue_generated), 0);
    const cpl = totalLeads > 0 ? totalSpend / totalLeads : 0;
    const conversionRate = totalLeads > 0 ? (totalConversions / totalLeads) * 100 : 0;
    const roi = totalSpend > 0 ? ((totalRevenue - totalSpend) / totalSpend) * 100 : 0;
    return { totalLeads, cpl, conversionRate, roi, totalRevenue, totalSpend };
  }, [filteredMetrics]);

  // Per-client metrics for chart
  const clientChartData = useMemo(() => {
    const map = new Map<string, { name: string; leads: number; conversions: number; spend: number; revenue: number }>();
    filteredMetrics.forEach((m) => {
      const client = clients.find((c) => c.id === m.client_id);
      if (!client) return;
      const existing = map.get(m.client_id) || { name: client.name, leads: 0, conversions: 0, spend: 0, revenue: 0 };
      existing.leads += m.leads_generated;
      existing.conversions += m.conversions;
      existing.spend += Number(m.ad_spend);
      existing.revenue += Number(m.revenue_generated);
      map.set(m.client_id, existing);
    });
    return Array.from(map.values());
  }, [filteredMetrics, clients]);

  // Generate alerts from performance data
  const alerts = useMemo(() => {
    const alertList: { type: "risk" | "opportunity"; message: string; client: string; severity: "high" | "medium" | "low" }[] = [];
    clientChartData.forEach((cd) => {
      const cpl = cd.leads > 0 ? cd.spend / cd.leads : 0;
      const roi = cd.spend > 0 ? ((cd.revenue - cd.spend) / cd.spend) * 100 : 0;
      if (cd.leads === 0 && cd.spend > 0) {
        alertList.push({ type: "risk", message: `Investimento sem leads gerados`, client: cd.name, severity: "high" });
      } else if (roi < 0) {
        alertList.push({ type: "risk", message: `ROI negativo: ${roi.toFixed(0)}%`, client: cd.name, severity: "high" });
      } else if (cpl > 100) {
        alertList.push({ type: "risk", message: `CPL alto: ${formatCurrency(cpl)}`, client: cd.name, severity: "medium" });
      }
      if (roi > 200) {
        alertList.push({ type: "opportunity", message: `ROI excepcional: ${roi.toFixed(0)}% — escalar orçamento`, client: cd.name, severity: "low" });
      }
      if (cd.conversions > 0 && cd.leads > 0 && (cd.conversions / cd.leads) > 0.3) {
        alertList.push({ type: "opportunity", message: `Taxa de conversão acima de 30%`, client: cd.name, severity: "low" });
      }
    });
    // Deliverables alerts
    deliverables.forEach((d) => {
      if (d.status === "Atrasado") {
        alertList.push({ type: "risk", message: `Entregável atrasado: "${d.title}"`, client: d.client_name || "Interno", severity: "high" });
      }
      if (d.due_date) {
        const daysLeft = (new Date(d.due_date).getTime() - Date.now()) / 86400000;
        if (daysLeft >= 0 && daysLeft <= 2 && d.status !== "Entregue" && d.status !== "Aprovado") {
          alertList.push({ type: "risk", message: `Prazo em ${Math.ceil(daysLeft)} dia(s): "${d.title}"`, client: d.client_name || "Interno", severity: "medium" });
        }
      }
    });
    return alertList.sort((a, b) => {
      const sev = { high: 0, medium: 1, low: 2 };
      return sev[a.severity] - sev[b.severity];
    });
  }, [clientChartData, deliverables]);

  // Group assets by category
  const assetsByCategory = useMemo(() => {
    const map = new Map<string, Asset[]>();
    assets.forEach((a) => {
      const list = map.get(a.category) || [];
      list.push(a);
      map.set(a.category, list);
    });
    return map;
  }, [assets]);

  // Group SOPs by category
  const sopsByCategory = useMemo(() => {
    const map = new Map<string, SOP[]>();
    sops.forEach((s) => {
      const list = map.get(s.category) || [];
      list.push(s);
      map.set(s.category, list);
    });
    return map;
  }, [sops]);

  // Group benchmarks by category
  const benchmarksByCategory = useMemo(() => {
    const map = new Map<string, Benchmark[]>();
    benchmarks.forEach((b) => {
      const list = map.get(b.category) || [];
      list.push(b);
      map.set(b.category, list);
    });
    return map;
  }, [benchmarks]);


  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="font-body text-sm text-champagne/40 tracking-wider">Carregando...</p>
      </div>
    );
  }

  const kpiCards = [
    { label: "MRR (Clientes Ativos)", value: formatCurrency(kpi.mrr), icon: TrendingUp, color: "text-green-400" },
    { label: "Receita Avulsa", value: formatCurrency(kpi.revenue_oneoff), icon: Wallet, color: "text-champagne" },
    { label: "Custos Operacionais", value: formatCurrency(kpi.operational_costs), icon: TrendingDown, color: "text-red-400/70" },
    { label: "Investimentos", value: formatCurrency(kpi.investments), icon: BarChart3, color: "text-gold" },
  ];

  const activeClients = clients.filter((c) => c.status === "Ativo").length;
  const thClass = "text-left px-5 py-3 font-body text-[10px] tracking-[0.2em] uppercase text-champagne/30 font-medium";

  const periodButtons: { key: PeriodFilter; label: string }[] = [
    { key: "today", label: "Hoje" },
    { key: "7days", label: "7 dias" },
    { key: "month", label: "Este mês" },
  ];

  // Pipeline grouped by status for kanban view
  const pipelineColumns = ["Novo", "Qualificado", "Em Negociação", "Convertido", "Perdido"];

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? "w-56" : "w-14"} shrink-0 border-r border-gold/10 bg-card flex flex-col transition-all duration-300 hidden md:flex`}>
        <div className="px-5 py-6 border-b border-gold/10">
          {sidebarOpen ? (
            <>
              <img src={logoSeid} alt="SEID" className="h-7 object-contain" />
              <p className="font-body text-[9px] tracking-[0.2em] uppercase text-gold/30 mt-2">Painel dos Sócios</p>
            </>
          ) : (
            <img src={logoSeid} alt="SEID" className="h-5 object-contain" />
          )}
        </div>

        <nav className="flex-1 py-4">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`w-full flex items-center gap-3 px-5 py-3 font-body text-xs tracking-wider transition-colors duration-200 ${
                  active ? "text-gold bg-secondary/50 border-r-2 border-gold" : "text-champagne/40 hover:text-champagne/70"
                }`}
                title={tab.label}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {sidebarOpen && tab.label}
              </button>
            );
          })}
        </nav>

        <div className="p-5 border-t border-gold/10 space-y-3">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="font-body text-[10px] tracking-wider text-champagne/20 hover:text-champagne/40 transition-colors">
            {sidebarOpen ? "← Recolher" : "→"}
          </button>
          <button onClick={handleLogout} className="flex items-center gap-2 font-body text-[10px] tracking-wider text-champagne/30 hover:text-red-400 transition-colors">
            <LogOut className="w-3.5 h-3.5" />
            {sidebarOpen && "Sair"}
          </button>
        </div>
      </aside>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-gold/10 flex">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.key;
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`flex-1 py-3 flex flex-col items-center gap-1 ${active ? "text-gold" : "text-champagne/30"}`}>
              <Icon className="w-4 h-4" />
              <span className="text-[8px] tracking-wider">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto pb-20 md:pb-0">
        <header className="px-6 md:px-8 py-5 md:py-6 border-b border-gold/10 flex items-center justify-between">
          <div>
            <h1 className="font-display text-lg md:text-xl text-champagne editorial-spacing">
              {tabs.find((t) => t.key === activeTab)?.label}
            </h1>
            <p className="font-body text-[10px] text-champagne/30 tracking-wider mt-1">
              {activeClients} clientes ativos • Fev 2026
            </p>
          </div>
          <button onClick={handleLogout} className="md:hidden text-champagne/30 hover:text-red-400 transition-colors">
            <LogOut className="w-4 h-4" />
          </button>
        </header>

        <div className="p-5 md:p-8">
          {/* === OVERVIEW === */}
          {activeTab === "overview" && (
            <div className="space-y-8">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
                {kpiCards.map((card) => {
                  const Icon = card.icon;
                  return (
                    <div key={card.label} className="border border-gold/15 p-5 md:p-6 hover:border-gold/30 transition-colors">
                      <div className="flex items-center gap-2 mb-3">
                        <Icon className={`w-4 h-4 ${card.color} opacity-70`} />
                        <span className="font-body text-[9px] md:text-[10px] tracking-[0.2em] uppercase text-champagne/35">{card.label}</span>
                      </div>
                      <p className={`font-body text-xl md:text-2xl font-semibold ${card.color}`}>{card.value}</p>
                    </div>
                  );
                })}
              </div>

              <div className="border border-gold/15 p-6">
                <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-4">Dashboard Looker Studio</p>
                <div className="bg-secondary/30 rounded-sm flex items-center justify-center aspect-video border border-dashed border-gold/15">
                  <div className="text-center">
                    <BarChart3 className="w-10 h-10 text-gold/20 mx-auto mb-3" />
                    <p className="font-body text-xs text-champagne/30">Cole a URL do seu Looker Studio para embutir o dashboard aqui</p>
                  </div>
                </div>
              </div>

              <div className="border border-gold/15">
                <div className="px-5 md:px-6 py-4 border-b border-gold/10">
                  <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Clientes Ativos</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[600px]">
                    <thead>
                      <tr className="border-b border-gold/10">
                        <th className={thClass}>Cliente</th>
                        <th className={thClass}>Status</th>
                        <th className={thClass}>Próx. Cobrança</th>
                        <th className={`${thClass} text-right`}>Valor Mensal</th>
                        <th className={`${thClass} text-center`}>Drive</th>
                      </tr>
                    </thead>
                    <tbody>
                      {clients.map((client) => (
                        <tr key={client.id} className="border-b border-gold/5 hover:bg-secondary/20 transition-colors">
                          <td className="px-5 py-4 font-body text-sm text-champagne/80">{client.name}</td>
                          <td className="px-5 py-4">
                            <span className={`font-body text-[10px] tracking-wider px-3 py-1 rounded-full ${client.status === "Ativo" ? "bg-green-500/10 text-green-400" : "bg-gold/10 text-gold/70"}`}>
                              {client.status}
                            </span>
                          </td>
                          <td className="px-5 py-4 font-body text-xs text-champagne/50">
                            {client.next_billing ? new Date(client.next_billing).toLocaleDateString("pt-BR") : "—"}
                          </td>
                          <td className="px-5 py-4 font-body text-sm text-champagne/70 text-right">
                            {client.monthly_value ? formatCurrency(client.monthly_value) : "—"}
                          </td>
                          <td className="px-5 py-4 text-center">
                            {client.drive_link && client.drive_link !== "#" ? (
                              <a href={client.drive_link} target="_blank" rel="noopener noreferrer" className="text-gold/50 hover:text-gold transition-colors">
                                <ExternalLink className="w-3.5 h-3.5 inline" />
                              </a>
                            ) : (
                              <span className="text-champagne/15">—</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* === COCKPIT DE PERFORMANCE === */}
          {activeTab === "cockpit" && (
            <div className="space-y-6">
              {/* Sub-tabs */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 border-b border-gold/10">
                {cockpitSubTabs.map((st) => {
                  const Icon = st.icon;
                  const active = cockpitSubTab === st.key;
                  return (
                    <button
                      key={st.key}
                      onClick={() => setCockpitSubTab(st.key)}
                      className={`flex items-center gap-2 px-4 py-2.5 font-body text-[10px] tracking-[0.15em] uppercase whitespace-nowrap border-b-2 transition-all duration-200 ${
                        active ? "border-gold text-gold" : "border-transparent text-champagne/30 hover:text-champagne/55"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {st.label}
                    </button>
                  );
                })}
              </div>

              {/* PERFORMANCE sub-tab */}
              {cockpitSubTab === "performance" && (
                <div className="space-y-8">
                  <div className="flex items-center justify-between flex-wrap gap-4">
                    <div>
                      <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-1">Métricas de Performance</p>
                      <p className="font-body text-[10px] text-champagne/25">Consolidado de todos os clientes</p>
                    </div>
                    <div className="flex gap-2">
                      {periodButtons.map((p) => (
                        <button
                          key={p.key}
                          onClick={() => setPeriodFilter(p.key)}
                          className={`font-body text-[10px] tracking-wider px-4 py-2 rounded-full border transition-all duration-300 ${
                            periodFilter === p.key ? "border-gold text-gold bg-gold/10" : "border-gold/15 text-champagne/30 hover:border-gold/30"
                          }`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      { label: "Leads Gerados", value: cockpitKPIs.totalLeads.toString(), icon: Zap, color: "text-green-400", trend: cockpitKPIs.totalLeads, prevTrend: cockpitKPIs.totalLeads * 0.9 },
                      { label: "CPL Médio", value: formatCurrency(cockpitKPIs.cpl), icon: Target, color: "text-gold", trend: cockpitKPIs.cpl, prevTrend: cockpitKPIs.cpl * 1.1 },
                      { label: "Taxa de Conversão", value: `${cockpitKPIs.conversionRate.toFixed(1)}%`, icon: Percent, color: "text-champagne", trend: cockpitKPIs.conversionRate, prevTrend: cockpitKPIs.conversionRate * 0.95 },
                      { label: "ROI", value: `${cockpitKPIs.roi.toFixed(0)}%`, icon: TrendingUp, color: cockpitKPIs.roi >= 100 ? "text-green-400" : "text-gold", trend: cockpitKPIs.roi, prevTrend: cockpitKPIs.roi * 0.9 },
                    ].map((card) => {
                      const Icon = card.icon;
                      return (
                        <div key={card.label} className="border border-gold/15 bg-secondary/20 p-5 md:p-6 hover:border-gold/30 transition-colors">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <Icon className={`w-4 h-4 ${card.color} opacity-70`} />
                              <span className="font-body text-[9px] md:text-[10px] tracking-[0.15em] uppercase text-champagne/35">{card.label}</span>
                            </div>
                            <TrendIcon value={card.trend} prev={card.prevTrend} />
                          </div>
                          <p className={`font-body text-xl md:text-2xl font-semibold ${card.color}`}>{card.value}</p>
                        </div>
                      );
                    })}
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="border border-gold/15 bg-secondary/10 p-5 md:p-6">
                      <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-5">Leads por Cliente</p>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={clientChartData} barSize={28}>
                            <CartesianGrid strokeDasharray="3 3" stroke="hsl(200 35% 24% / 0.4)" />
                            <XAxis dataKey="name" tick={{ fill: "hsl(34 53% 91% / 0.35)", fontSize: 10, fontFamily: "Montserrat" }} axisLine={{ stroke: "hsl(30 37% 59% / 0.15)" }} tickLine={false} />
                            <YAxis tick={{ fill: "hsl(34 53% 91% / 0.25)", fontSize: 10, fontFamily: "Montserrat" }} axisLine={false} tickLine={false} />
                            <Tooltip contentStyle={{ backgroundColor: "hsl(200 45% 14%)", border: "1px solid hsl(30 37% 59% / 0.2)", borderRadius: "4px", fontFamily: "Montserrat", fontSize: 11, color: "hsl(34 53% 91%)" }} />
                            <Bar dataKey="leads" name="Leads" fill="hsl(30 37% 59% / 0.7)" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="conversions" name="Conversões" fill="hsl(142 76% 56% / 0.5)" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                    <div className="border border-gold/15 bg-secondary/10 p-5 md:p-6">
                      <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-5">Receita vs Investimento</p>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={clientChartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="hsl(200 35% 24% / 0.4)" />
                            <XAxis dataKey="name" tick={{ fill: "hsl(34 53% 91% / 0.35)", fontSize: 10, fontFamily: "Montserrat" }} axisLine={{ stroke: "hsl(30 37% 59% / 0.15)" }} tickLine={false} />
                            <YAxis tick={{ fill: "hsl(34 53% 91% / 0.25)", fontSize: 10, fontFamily: "Montserrat" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                            <Tooltip contentStyle={{ backgroundColor: "hsl(200 45% 14%)", border: "1px solid hsl(30 37% 59% / 0.2)", borderRadius: "4px", fontFamily: "Montserrat", fontSize: 11, color: "hsl(34 53% 91%)" }} formatter={(value: number) => formatCurrency(value)} />
                            <Line type="monotone" dataKey="revenue" name="Receita" stroke="hsl(142 76% 56% / 0.7)" strokeWidth={2} dot={{ fill: "hsl(142 76% 56%)", r: 4 }} />
                            <Line type="monotone" dataKey="spend" name="Investimento" stroke="hsl(30 37% 59% / 0.7)" strokeWidth={2} dot={{ fill: "hsl(30 37% 59%)", r: 4 }} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>

                  {/* Client table + individual cards */}
                  <div className="border border-gold/15">
                    <div className="px-5 md:px-6 py-4 border-b border-gold/10 flex items-center justify-between">
                      <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Dashboard de Clientes Ativos</p>
                      <span className="font-body text-[10px] text-champagne/25">{clients.filter((c) => c.campaign_status === "Ativa").length} campanhas ativas</span>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[700px]">
                        <thead>
                          <tr className="border-b border-gold/10">
                            <th className={thClass}>Cliente</th>
                            <th className={thClass}>Serviço Contratado</th>
                            <th className={thClass}>Status Campanha</th>
                            <th className={thClass}>Renovação</th>
                            <th className={`${thClass} text-center`}>Editar</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clients.map((client) => (
                            <tr key={client.id} className="border-b border-gold/5 hover:bg-secondary/20 transition-colors">
                              <td className="px-5 py-4 font-body text-sm text-champagne/80">{client.name}</td>
                              <td className="px-5 py-4 font-body text-xs text-champagne/55">{client.service}</td>
                              <td className="px-5 py-4">
                                <span className={`font-body text-[10px] tracking-wider px-3 py-1 rounded-full ${client.campaign_status === "Ativa" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400/70"}`}>
                                  {client.campaign_status}
                                </span>
                              </td>
                              <td className="px-5 py-4 font-body text-xs text-champagne/50">
                                {client.next_billing ? new Date(client.next_billing).toLocaleDateString("pt-BR") : "—"}
                              </td>
                              <td className="px-5 py-4 text-center">
                                <button className="text-gold/40 hover:text-gold transition-colors p-1" title={`Editar ${client.name}`} onClick={() => { if (client.drive_link && client.drive_link !== "#") window.open(client.drive_link, "_blank"); }}>
                                  <Pencil className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div>
                    <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-4">Performance Individual</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {clientChartData.map((cd) => {
                        const clientCpl = cd.leads > 0 ? cd.spend / cd.leads : 0;
                        const clientConv = cd.leads > 0 ? (cd.conversions / cd.leads) * 100 : 0;
                        const clientRoi = cd.spend > 0 ? ((cd.revenue - cd.spend) / cd.spend) * 100 : 0;
                        return (
                          <div key={cd.name} className="border border-gold/15 bg-secondary/20 p-5 hover:border-gold/30 transition-colors">
                            <p className="font-body text-xs text-champagne/70 font-medium mb-4">{cd.name}</p>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <p className="font-body text-[9px] tracking-wider text-champagne/25 uppercase">Leads</p>
                                <p className="font-body text-lg text-green-400 font-semibold">{cd.leads}</p>
                              </div>
                              <div>
                                <p className="font-body text-[9px] tracking-wider text-champagne/25 uppercase">CPL</p>
                                <p className="font-body text-lg text-gold font-semibold">{formatCurrency(clientCpl)}</p>
                              </div>
                              <div>
                                <p className="font-body text-[9px] tracking-wider text-champagne/25 uppercase">Conversão</p>
                                <p className="font-body text-lg text-champagne font-semibold">{clientConv.toFixed(1)}%</p>
                              </div>
                              <div>
                                <p className="font-body text-[9px] tracking-wider text-champagne/25 uppercase">ROI</p>
                                <p className={`font-body text-lg font-semibold ${clientRoi >= 100 ? "text-green-400" : "text-gold"}`}>{clientRoi.toFixed(0)}%</p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* RADAR DE ALERTAS sub-tab */}
              {cockpitSubTab === "alerts" && (
                <div className="space-y-6">
                  <div>
                    <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-1">Radar de Alertas</p>
                    <p className="font-body text-[10px] text-champagne/25">Notificações automáticas baseadas em variações de performance</p>
                  </div>

                  {alerts.length === 0 ? (
                    <div className="border border-gold/15 p-10 text-center">
                      <AlertTriangle className="w-10 h-10 text-green-400/30 mx-auto mb-3" />
                      <p className="font-body text-sm text-champagne/40">Nenhum alerta no momento</p>
                      <p className="font-body text-[10px] text-champagne/20 mt-1">Todos os indicadores estão dentro do esperado</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {alerts.map((alert, i) => (
                        <div
                          key={i}
                          className={`border p-4 md:p-5 flex items-start gap-4 transition-colors hover:border-gold/30 ${
                            alert.severity === "high" ? "border-red-500/30 bg-red-500/5" : alert.severity === "medium" ? "border-gold/20 bg-gold/5" : "border-green-500/20 bg-green-500/5"
                          }`}
                        >
                          <div className={`mt-0.5 ${alert.type === "risk" ? "text-red-400" : "text-green-400"}`}>
                            {alert.type === "risk" ? <AlertTriangle className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className={`font-body text-[9px] tracking-[0.15em] uppercase font-medium ${alert.type === "risk" ? "text-red-400" : "text-green-400"}`}>
                                {alert.type === "risk" ? "Risco" : "Oportunidade"}
                              </span>
                              <span className={`font-body text-[9px] tracking-wider px-2 py-0.5 rounded-full ${
                                alert.severity === "high" ? "bg-red-500/15 text-red-400" : alert.severity === "medium" ? "bg-gold/15 text-gold" : "bg-green-500/15 text-green-400"
                              }`}>
                                {alert.severity === "high" ? "Alta" : alert.severity === "medium" ? "Média" : "Baixa"}
                              </span>
                            </div>
                            <p className="font-body text-sm text-champagne/70">{alert.message}</p>
                            <p className="font-body text-[10px] text-champagne/30 mt-1">{alert.client}</p>
                          </div>
                          <ChevronRight className="w-4 h-4 text-champagne/15 shrink-0 mt-1" />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* PIPELINE COMERCIAL sub-tab */}
              {cockpitSubTab === "pipeline" && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between flex-wrap gap-4">
                    <div>
                      <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-1">Pipeline Comercial</p>
                      <p className="font-body text-[10px] text-champagne/25">Leads do Diagnóstico • {pipelineLeads.length} registros</p>
                    </div>
                  </div>

                  {pipelineLeads.length === 0 ? (
                    <div className="border border-gold/15 p-10 text-center">
                      <Kanban className="w-10 h-10 text-gold/20 mx-auto mb-3" />
                      <p className="font-body text-sm text-champagne/40">Nenhum lead no pipeline</p>
                      <p className="font-body text-[10px] text-champagne/20 mt-1">Os leads do formulário de diagnóstico aparecerão aqui</p>
                    </div>
                  ) : (
                    <>
                      {/* Kanban-style columns on desktop, table on mobile */}
                      <div className="hidden lg:grid lg:grid-cols-5 gap-4">
                        {pipelineColumns.map((col) => {
                          const colLeads = pipelineLeads.filter((l) => l.status === col);
                          return (
                            <div key={col} className="space-y-3">
                              <div className="flex items-center justify-between px-1">
                                <span className={`font-body text-[10px] tracking-[0.15em] uppercase font-medium ${pipelineStatusColor[col]?.split(" ")[1] || "text-champagne/40"}`}>{col}</span>
                                <span className="font-body text-[9px] text-champagne/20">{colLeads.length}</span>
                              </div>
                              <div className="space-y-2 min-h-[100px]">
                                {colLeads.map((lead) => (
                                  <div key={lead.id} className="border border-gold/15 bg-secondary/20 p-4 hover:border-gold/30 transition-colors">
                                    <div className="flex items-center justify-between mb-2">
                                      <span className={`font-body text-[9px] tracking-wider px-2 py-0.5 rounded-full ${priorityColor[lead.priority] || "bg-champagne/10 text-champagne/40"}`}>{lead.priority}</span>
                                      <span className="font-body text-[9px] text-champagne/20">{new Date(lead.created_at).toLocaleDateString("pt-BR")}</span>
                                    </div>
                                    <p className="font-body text-xs text-champagne/70 font-medium mb-1">{lead.name}</p>
                                    {lead.company && <p className="font-body text-[10px] text-champagne/35">{lead.company}</p>}
                                    {lead.email && <p className="font-body text-[10px] text-champagne/25 mt-1">{lead.email}</p>}
                                  </div>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Mobile table view */}
                      <div className="lg:hidden border border-gold/15">
                        <div className="overflow-x-auto">
                          <table className="w-full min-w-[500px]">
                            <thead>
                              <tr className="border-b border-gold/10">
                                <th className={thClass}>Lead</th>
                                <th className={thClass}>Status</th>
                                <th className={thClass}>Prioridade</th>
                                <th className={thClass}>Data</th>
                              </tr>
                            </thead>
                            <tbody>
                              {pipelineLeads.map((lead) => (
                                <tr key={lead.id} className="border-b border-gold/5 hover:bg-secondary/20 transition-colors">
                                  <td className="px-5 py-4">
                                    <p className="font-body text-sm text-champagne/80">{lead.name}</p>
                                    {lead.company && <p className="font-body text-[10px] text-champagne/30">{lead.company}</p>}
                                  </td>
                                  <td className="px-5 py-4">
                                    <span className={`font-body text-[10px] tracking-wider px-3 py-1 rounded-full ${pipelineStatusColor[lead.status] || "bg-champagne/10 text-champagne/40"}`}>{lead.status}</span>
                                  </td>
                                  <td className="px-5 py-4">
                                    <span className={`font-body text-[10px] tracking-wider px-2 py-0.5 rounded-full ${priorityColor[lead.priority] || "bg-champagne/10 text-champagne/40"}`}>{lead.priority}</span>
                                  </td>
                                  <td className="px-5 py-4 font-body text-xs text-champagne/40">{new Date(lead.created_at).toLocaleDateString("pt-BR")}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* GESTÃO DE CAPACIDADE sub-tab */}
              {cockpitSubTab === "capacity" && (
                <div className="space-y-6">
                  <div>
                    <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-1">Gestão de Capacidade</p>
                    <p className="font-body text-[10px] text-champagne/25">Entregáveis da semana • {deliverables.length} projetos</p>
                  </div>

                  {deliverables.length === 0 ? (
                    <div className="border border-gold/15 p-10 text-center">
                      <CalendarCheck className="w-10 h-10 text-gold/20 mx-auto mb-3" />
                      <p className="font-body text-sm text-champagne/40">Nenhum entregável cadastrado</p>
                      <p className="font-body text-[10px] text-champagne/20 mt-1">Adicione projetos de vídeo, sites e criativos para monitorar prazos</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {deliverables.map((d) => {
                        const TypeIcon = deliverableTypeIcon[d.type] || FileText;
                        const daysLeft = d.due_date ? Math.ceil((new Date(d.due_date).getTime() - Date.now()) / 86400000) : null;
                        return (
                          <div key={d.id} className="border border-gold/15 bg-secondary/20 p-5 hover:border-gold/30 transition-colors">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <TypeIcon className="w-4 h-4 text-gold/50" />
                                <span className="font-body text-[9px] tracking-wider text-champagne/30 uppercase">{d.type}</span>
                              </div>
                              <span className={`font-body text-[9px] tracking-wider px-2.5 py-0.5 rounded-full ${deliverableStatusColor[d.status] || "bg-champagne/10 text-champagne/40"}`}>
                                {d.status}
                              </span>
                            </div>
                            <p className="font-body text-sm text-champagne/75 font-medium mb-1">{d.title}</p>
                            {d.client_name && <p className="font-body text-[10px] text-champagne/30 mb-3">{d.client_name}</p>}
                            <div className="flex items-center justify-between mt-3 pt-3 border-t border-gold/10">
                              {d.assignee && (
                                <span className="font-body text-[10px] text-champagne/25">
                                  👤 {d.assignee}
                                </span>
                              )}
                              {daysLeft !== null && (
                                <span className={`font-body text-[10px] flex items-center gap-1 ${daysLeft < 0 ? "text-red-400" : daysLeft <= 2 ? "text-gold" : "text-champagne/30"}`}>
                                  <Clock className="w-3 h-3" />
                                  {daysLeft < 0 ? `${Math.abs(daysLeft)}d atrasado` : daysLeft === 0 ? "Hoje" : `${daysLeft}d restantes`}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* REPOSITÓRIO DE ATIVOS sub-tab */}
              {cockpitSubTab === "assets" && (
                <div className="space-y-6">
                  <div>
                    <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-1">Repositório de Ativos</p>
                    <p className="font-body text-[10px] text-champagne/25">Links rápidos para contratos, templates e criativos</p>
                  </div>

                  {assets.length === 0 ? (
                    <div className="space-y-4">
                      <div className="border border-gold/15 p-10 text-center">
                        <FolderOpen className="w-10 h-10 text-gold/20 mx-auto mb-3" />
                        <p className="font-body text-sm text-champagne/40">Nenhum ativo cadastrado</p>
                        <p className="font-body text-[10px] text-champagne/20 mt-1">Adicione links para contratos, templates de n8n e criativos vencedores</p>
                      </div>

                      {/* Default quick links as placeholder */}
                      <div>
                        <p className="font-body text-[10px] tracking-[0.2em] uppercase text-champagne/25 mb-3">Links Sugeridos</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {[
                            { label: "Contratos & Propostas", icon: FileText, desc: "Templates de contratos padrão" },
                            { label: "Templates n8n", icon: Zap, desc: "Automações e workflows" },
                            { label: "Criativos Vencedores", icon: Target, desc: "Pasta de anúncios com melhor performance" },
                          ].map((item) => {
                            const Icon = item.icon;
                            return (
                              <div key={item.label} className="border border-dashed border-gold/15 p-5 opacity-40">
                                <div className="flex items-center gap-3 mb-2">
                                  <Icon className="w-5 h-5 text-gold/40" />
                                  <span className="font-body text-xs text-champagne/50 font-medium">{item.label}</span>
                                </div>
                                <p className="font-body text-[10px] text-champagne/25">{item.desc}</p>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {Array.from(assetsByCategory.entries()).map(([category, items]) => (
                        <div key={category}>
                          <p className="font-body text-[10px] tracking-[0.2em] uppercase text-champagne/30 mb-3">{category}</p>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                            {items.map((asset) => (
                              <a
                                key={asset.id}
                                href={asset.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="border border-gold/15 bg-secondary/20 p-4 flex items-center gap-3 hover:border-gold/30 hover:bg-secondary/30 transition-all group"
                              >
                                <Link2 className="w-4 h-4 text-gold/40 group-hover:text-gold transition-colors shrink-0" />
                                <span className="font-body text-xs text-champagne/60 group-hover:text-champagne/80 transition-colors truncate">{asset.label}</span>
                                <ExternalLink className="w-3 h-3 text-champagne/15 group-hover:text-gold/50 transition-colors ml-auto shrink-0" />
                              </a>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* === CLIENTS === */}
          {activeTab === "clients" && (
            <div className="space-y-6">
            <div className="border border-gold/15">
              <div className="px-5 md:px-6 py-4 border-b border-gold/10 flex items-center justify-between">
                <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Todos os Clientes</p>
                <span className="font-body text-[10px] text-champagne/25">{clients.length} registros</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[650px]">
                  <thead>
                    <tr className="border-b border-gold/10">
                      <th className={thClass}>Cliente</th>
                      <th className={thClass}>Serviço</th>
                      <th className={thClass}>Status</th>
                      <th className={thClass}>Campanha</th>
                      <th className={thClass}>Próx. Cobrança</th>
                      <th className={`${thClass} text-right`}>Valor Mensal</th>
                      <th className={`${thClass} text-center`}>Drive</th>
                    </tr>
                  </thead>
                  <tbody>
                    {clients.map((client) => (
                      <tr key={client.id} className="border-b border-gold/5 hover:bg-secondary/20 transition-colors">
                        <td className="px-5 py-4 font-body text-sm text-champagne/80">{client.name}</td>
                        <td className="px-5 py-4 font-body text-xs text-champagne/50">{client.service}</td>
                        <td className="px-5 py-4">
                          <span className={`font-body text-[10px] tracking-wider px-3 py-1 rounded-full ${client.status === "Ativo" ? "bg-green-500/10 text-green-400" : "bg-gold/10 text-gold/70"}`}>
                            {client.status}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <span className={`font-body text-[10px] tracking-wider px-3 py-1 rounded-full ${client.campaign_status === "Ativa" ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400/70"}`}>
                            {client.campaign_status}
                          </span>
                        </td>
                        <td className="px-5 py-4 font-body text-xs text-champagne/50">
                          {client.next_billing ? new Date(client.next_billing).toLocaleDateString("pt-BR") : "—"}
                        </td>
                        <td className="px-5 py-4 font-body text-sm text-champagne/70 text-right">
                          {client.monthly_value ? formatCurrency(client.monthly_value) : "—"}
                        </td>
                        <td className="px-5 py-4 text-center">
                          {client.drive_link && client.drive_link !== "#" ? (
                            <a href={client.drive_link} target="_blank" rel="noopener noreferrer" className="text-gold/50 hover:text-gold transition-colors">
                              <ExternalLink className="w-3.5 h-3.5 inline" />
                            </a>
                          ) : (
                            <span className="text-champagne/15">—</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Client Files Management */}
            <div className="border border-gold/15 mt-6">
              <div className="px-5 md:px-6 py-4 border-b border-gold/10 flex items-center gap-2.5">
                <FolderOpen className="w-4 h-4 text-gold/40" />
                <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Gerenciar Arquivos dos Clientes</p>
              </div>

              <div className="p-5 md:p-6 border-b border-gold/10">
                {fileMsg && (
                  <div className={`mb-4 p-3 border rounded-sm flex items-center gap-2 ${fileMsg.type === "success" ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                    <CheckCircle className={`w-3.5 h-3.5 shrink-0 ${fileMsg.type === "success" ? "text-green-400" : "text-red-400"}`} />
                    <p className={`font-body text-xs ${fileMsg.type === "success" ? "text-green-400" : "text-red-400"}`}>{fileMsg.text}</p>
                  </div>
                )}
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    setFileLoading(true);
                    setFileMsg(null);
                    const { error } = await supabase.from("client_files").insert({
                      client_id: fileFormClient,
                      label: fileFormLabel,
                      url: fileFormUrl,
                      category: fileFormCategory,
                    });
                    setFileLoading(false);
                    if (error) {
                      setFileMsg({ type: "error", text: error.message });
                    } else {
                      setFileMsg({ type: "success", text: `Arquivo "${fileFormLabel}" adicionado com sucesso.` });
                      setFileFormLabel("");
                      setFileFormUrl("");
                      const { data } = await supabase.from("client_files").select("*").order("created_at", { ascending: false });
                      if (data) setClientFiles(data as any[]);
                    }
                  }}
                  className="grid grid-cols-1 md:grid-cols-5 gap-3 items-end"
                >
                  <div>
                    <label className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30 mb-1 block">Cliente</label>
                    <select value={fileFormClient} onChange={(e) => setFileFormClient(e.target.value)} required className="w-full bg-transparent border border-gold/20 rounded-sm px-3 py-2 font-body text-xs text-champagne/80 focus:outline-none focus:border-gold/50">
                      <option value="" className="bg-background">Selecione...</option>
                      {clients.map((c) => (<option key={c.id} value={c.id} className="bg-background">{c.name}</option>))}
                    </select>
                  </div>
                  <div>
                    <label className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30 mb-1 block">Nome do Arquivo</label>
                    <input type="text" value={fileFormLabel} onChange={(e) => setFileFormLabel(e.target.value)} placeholder="Ex: Criativos Fev/2026" required className="w-full bg-transparent border border-gold/20 rounded-sm px-3 py-2 font-body text-xs text-champagne/80 placeholder:text-champagne/15 focus:outline-none focus:border-gold/50" />
                  </div>
                  <div>
                    <label className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30 mb-1 block">URL do Arquivo</label>
                    <input type="url" value={fileFormUrl} onChange={(e) => setFileFormUrl(e.target.value)} placeholder="https://drive.google.com/..." required className="w-full bg-transparent border border-gold/20 rounded-sm px-3 py-2 font-body text-xs text-champagne/80 placeholder:text-champagne/15 focus:outline-none focus:border-gold/50" />
                  </div>
                  <div>
                    <label className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30 mb-1 block">Categoria</label>
                    <select value={fileFormCategory} onChange={(e) => setFileFormCategory(e.target.value)} className="w-full bg-transparent border border-gold/20 rounded-sm px-3 py-2 font-body text-xs text-champagne/80 focus:outline-none focus:border-gold/50">
                      <option value="Criativos" className="bg-background">Criativos</option>
                      <option value="Vídeos" className="bg-background">Vídeos</option>
                      <option value="Contratos" className="bg-background">Contratos</option>
                    </select>
                  </div>
                  <button type="submit" disabled={fileLoading} className="flex items-center justify-center gap-1.5 font-body text-[10px] tracking-[0.2em] uppercase bg-gold text-background py-2 px-4 rounded-sm hover:bg-champagne transition-colors font-semibold disabled:opacity-50">
                    <Plus className="w-3.5 h-3.5" />
                    {fileLoading ? "Salvando..." : "Adicionar"}
                  </button>
                </form>
              </div>

              <div className="flex items-center gap-3 mb-4">
                <select value={filterFileClient} onChange={(e) => setFilterFileClient(e.target.value)} className="bg-transparent border border-gold/20 rounded-sm px-3 py-1.5 font-body text-xs text-champagne/70 focus:outline-none focus:border-gold/50">
                  <option value="" className="bg-background">Todos os clientes</option>
                  {clients.map((c) => (<option key={c.id} value={c.id} className="bg-background">{c.name}</option>))}
                </select>
                <select value={filterFileCategory} onChange={(e) => setFilterFileCategory(e.target.value)} className="bg-transparent border border-gold/20 rounded-sm px-3 py-1.5 font-body text-xs text-champagne/70 focus:outline-none focus:border-gold/50">
                  <option value="" className="bg-background">Todas as categorias</option>
                  <option value="Criativos" className="bg-background">Criativos</option>
                  <option value="Vídeos" className="bg-background">Vídeos</option>
                  <option value="Contratos" className="bg-background">Contratos</option>
                </select>
                <span className="font-body text-[9px] text-champagne/30 tracking-wider">{filteredClientFiles.length} arquivo(s)</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full min-w-[550px]">
                  <thead>
                    <tr className="border-b border-gold/10">
                      <th className={thClass}>Cliente</th>
                      <th className={thClass}>Arquivo</th>
                      <th className={thClass}>Categoria</th>
                      <th className={`${thClass} text-center`}>Link</th>
                      <th className={`${thClass} text-center`}>Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredClientFiles.length === 0 ? (
                      <tr><td colSpan={5} className="px-5 py-8 text-center font-body text-xs text-champagne/25">{clientFiles.length === 0 ? "Nenhum arquivo cadastrado." : "Nenhum arquivo encontrado com os filtros selecionados."}</td></tr>
                    ) : (
                      filteredClientFiles.map((f) => {
                        const cName = clients.find((c) => c.id === f.client_id)?.name || "—";
                        const isEditing = editingFileId === f.id;
                        return (
                          <tr key={f.id} className="border-b border-gold/5 hover:bg-secondary/20 transition-colors">
                            <td className="px-5 py-3 font-body text-xs text-champagne/70">{cName}</td>
                            <td className="px-5 py-3">
                              {isEditing ? (
                                <input type="text" value={editFileLabel} onChange={(e) => setEditFileLabel(e.target.value)} className="w-full bg-transparent border border-gold/30 rounded-sm px-2 py-1 font-body text-xs text-champagne/80 focus:outline-none focus:border-gold/50" />
                              ) : (
                                <span className="font-body text-xs text-champagne/80">{f.label}</span>
                              )}
                            </td>
                            <td className="px-5 py-3">
                              {isEditing ? (
                                <select value={editFileCategory} onChange={(e) => setEditFileCategory(e.target.value)} className="bg-transparent border border-gold/30 rounded-sm px-2 py-1 font-body text-xs text-champagne/80 focus:outline-none focus:border-gold/50">
                                  <option value="Criativos" className="bg-background">Criativos</option>
                                  <option value="Vídeos" className="bg-background">Vídeos</option>
                                  <option value="Contratos" className="bg-background">Contratos</option>
                                </select>
                              ) : (
                                <span className="font-body text-[9px] tracking-wider px-2.5 py-0.5 rounded-full bg-gold/10 text-gold/70">{f.category}</span>
                              )}
                            </td>
                            <td className="px-5 py-3 text-center">
                              {isEditing ? (
                                <input type="url" value={editFileUrl} onChange={(e) => setEditFileUrl(e.target.value)} className="w-full bg-transparent border border-gold/30 rounded-sm px-2 py-1 font-body text-xs text-champagne/80 focus:outline-none focus:border-gold/50" />
                              ) : (
                                <a href={f.url} target="_blank" rel="noopener noreferrer" className="text-gold/50 hover:text-gold transition-colors"><ExternalLink className="w-3.5 h-3.5 inline" /></a>
                              )}
                            </td>
                            <td className="px-5 py-3 text-center flex items-center justify-center gap-2">
                              {isEditing ? (
                                <>
                                  <button onClick={async () => {
                                    const { error } = await supabase.from("client_files").update({ label: editFileLabel, url: editFileUrl, category: editFileCategory }).eq("id", f.id);
                                    if (!error) {
                                      setClientFiles((prev) => prev.map((x) => x.id === f.id ? { ...x, label: editFileLabel, url: editFileUrl, category: editFileCategory } : x));
                                      setEditingFileId(null);
                                    }
                                  }} className="text-green-400/60 hover:text-green-400 transition-colors"><CheckCircle className="w-3.5 h-3.5" /></button>
                                  <button onClick={() => setEditingFileId(null)} className="text-champagne/30 hover:text-champagne/60 transition-colors"><RotateCcw className="w-3.5 h-3.5" /></button>
                                </>
                              ) : (
                                <>
                                  <button onClick={() => { setEditingFileId(f.id); setEditFileLabel(f.label); setEditFileUrl(f.url); setEditFileCategory(f.category); }} className="text-gold/40 hover:text-gold transition-colors"><Pencil className="w-3.5 h-3.5" /></button>
                                  <button onClick={async () => { if (!confirm(`Remover "${f.label}"?`)) return; await supabase.from("client_files").delete().eq("id", f.id); setClientFiles((prev) => prev.filter((x) => x.id !== f.id)); }} className="text-red-400/40 hover:text-red-400 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                                </>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            </div>
          )}

          {/* === FINANCIAL === */}
          {activeTab === "financial" && (
            <div className="space-y-8">
              <div className="grid grid-cols-2 gap-4 md:gap-5">
                {kpiCards.map((card) => {
                  const Icon = card.icon;
                  return (
                    <div key={card.label} className="border border-gold/15 p-6 md:p-8 hover:border-gold/30 transition-colors">
                      <div className="flex items-center gap-2 mb-4">
                        <Icon className={`w-5 h-5 ${card.color} opacity-70`} />
                        <span className="font-body text-[9px] md:text-[10px] tracking-[0.2em] uppercase text-champagne/35">{card.label}</span>
                      </div>
                      <p className={`font-body text-2xl md:text-3xl font-semibold ${card.color}`}>{card.value}</p>
                    </div>
                  );
                })}
              </div>

              <div className="border border-gold/15 p-6">
                <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-2">Resumo</p>
                <div className="gold-line w-8 opacity-20 mb-4" />
                <div className="flex justify-between items-center py-3 border-b border-gold/5">
                  <span className="font-body text-xs text-champagne/50">Receita Total</span>
                  <span className="font-body text-sm text-green-400 font-medium">{formatCurrency(kpi.mrr + kpi.revenue_oneoff)}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gold/5">
                  <span className="font-body text-xs text-champagne/50">Saídas Total</span>
                  <span className="font-body text-sm text-red-400/70 font-medium">{formatCurrency(kpi.operational_costs + kpi.investments)}</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="font-body text-xs text-champagne/70 font-medium">Resultado Líquido</span>
                  <span className={`font-body text-lg font-semibold ${(kpi.mrr + kpi.revenue_oneoff - kpi.operational_costs - kpi.investments) >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {formatCurrency(kpi.mrr + kpi.revenue_oneoff - kpi.operational_costs - kpi.investments)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* === GOVERNANÇA & ESTRATÉGIA === */}
          {activeTab === "governance" && (
            <div className="space-y-10">
              {/* Manual de Operações (SOPs) */}
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <BookOpen className="w-4 h-4 text-gold/50" />
                  <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Manual de Operações (SOPs)</p>
                </div>
                <p className="font-body text-[10px] text-champagne/25 mb-5">Documentos, fluxos de trabalho e roteiros para consulta rápida</p>

                {sops.length === 0 ? (
                  <div className="border border-gold/15 p-8 text-center">
                    <BookOpen className="w-8 h-8 text-gold/15 mx-auto mb-3" />
                    <p className="font-body text-sm text-champagne/35">Nenhum SOP cadastrado</p>
                    <p className="font-body text-[10px] text-champagne/20 mt-1">Adicione links para fluxos n8n, contratos e roteiros operacionais</p>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {Array.from(sopsByCategory.entries()).map(([category, items]) => (
                      <div key={category}>
                        <p className="font-body text-[10px] tracking-[0.2em] uppercase text-champagne/25 mb-3">{category}</p>
                        <div className="space-y-2">
                          {items.map((sop) => (
                            <a
                              key={sop.id}
                              href={sop.url || "#"}
                              target={sop.url ? "_blank" : undefined}
                              rel="noopener noreferrer"
                              className="border border-gold/10 bg-secondary/10 p-4 flex items-center gap-4 hover:border-gold/25 transition-all group"
                            >
                              <FileText className="w-4 h-4 text-gold/30 group-hover:text-gold/60 transition-colors shrink-0" />
                              <div className="flex-1 min-w-0">
                                <p className="font-body text-xs text-champagne/65 group-hover:text-champagne/85 transition-colors">{sop.title}</p>
                                {sop.description && <p className="font-body text-[10px] text-champagne/20 mt-0.5 truncate">{sop.description}</p>}
                              </div>
                              {sop.url && <ExternalLink className="w-3 h-3 text-champagne/10 group-hover:text-gold/40 transition-colors shrink-0" />}
                            </a>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Radar de Benchmarking */}
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Eye className="w-4 h-4 text-gold/50" />
                  <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Radar de Benchmarking</p>
                </div>
                <p className="font-body text-[10px] text-champagne/25 mb-5">Referências de mercado para criativos e posicionamento</p>

                {benchmarks.length === 0 ? (
                  <div className="border border-gold/15 p-8 text-center">
                    <Eye className="w-8 h-8 text-gold/15 mx-auto mb-3" />
                    <p className="font-body text-sm text-champagne/35">Nenhuma referência salva</p>
                    <p className="font-body text-[10px] text-champagne/20 mt-1">Salve links de inspiração, benchmarks de criativos e posicionamento</p>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {Array.from(benchmarksByCategory.entries()).map(([category, items]) => (
                      <div key={category}>
                        <p className="font-body text-[10px] tracking-[0.2em] uppercase text-champagne/25 mb-3">{category}</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {items.map((bm) => (
                            <a
                              key={bm.id}
                              href={bm.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="border border-gold/10 bg-secondary/10 p-4 hover:border-gold/25 transition-all group"
                            >
                              <div className="flex items-center gap-2 mb-2">
                                <Link2 className="w-3.5 h-3.5 text-gold/30 group-hover:text-gold/60 transition-colors shrink-0" />
                                <span className="font-body text-xs text-champagne/60 group-hover:text-champagne/80 transition-colors truncate">{bm.title}</span>
                              </div>
                              {bm.notes && <p className="font-body text-[10px] text-champagne/20 truncate">{bm.notes}</p>}
                              <p className="font-body text-[9px] text-champagne/15 mt-2">{new Date(bm.created_at).toLocaleDateString("pt-BR")}</p>
                            </a>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Cashflow Projetado */}
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <DollarSign className="w-4 h-4 text-gold/50" />
                  <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Cashflow Projetado</p>
                </div>
                <p className="font-body text-[10px] text-champagne/25 mb-5">Receita garantida vs. projetos estimados</p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="border border-gold/15 bg-secondary/10 p-6">
                    <p className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/25 mb-3">Receita Recorrente Garantida</p>
                    <p className="font-body text-2xl md:text-3xl font-semibold text-green-400">{formatCurrency(kpi.mrr)}</p>
                    <p className="font-body text-[10px] text-champagne/20 mt-2">{clients.filter(c => c.status === "Ativo").length} contratos ativos</p>
                  </div>
                  <div className="border border-gold/15 bg-secondary/10 p-6">
                    <p className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/25 mb-3">Projetos Avulsos Estimados</p>
                    <p className="font-body text-2xl md:text-3xl font-semibold text-champagne">{formatCurrency(kpi.revenue_oneoff)}</p>
                    <p className="font-body text-[10px] text-champagne/20 mt-2">Receita pontual do período</p>
                  </div>
                  <div className="border border-gold/15 bg-secondary/10 p-6">
                    <p className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/25 mb-3">Diferença (Recorrente − Avulso)</p>
                    <p className={`font-body text-2xl md:text-3xl font-semibold ${kpi.mrr >= kpi.revenue_oneoff ? "text-green-400" : "text-gold"}`}>
                      {formatCurrency(kpi.mrr - kpi.revenue_oneoff)}
                    </p>
                    <p className="font-body text-[10px] text-champagne/20 mt-2">
                      {kpi.mrr >= kpi.revenue_oneoff ? "Base recorrente saudável" : "Dependência de avulsos — escalar MRR"}
                    </p>
                  </div>
                </div>
              </div>

              {/* CRM de Relacionamento (Pós-Venda) */}
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Phone className="w-4 h-4 text-gold/50" />
                  <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">CRM de Relacionamento (Pós-Venda)</p>
                </div>
                <p className="font-body text-[10px] text-champagne/25 mb-5">Último check-in com cada cliente • clientes sem contato há +15 dias em destaque</p>

                <div className="border border-gold/15">
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[550px]">
                      <thead>
                        <tr className="border-b border-gold/10">
                          <th className={thClass}>Cliente</th>
                          <th className={thClass}>Serviço</th>
                          <th className={thClass}>Último Check-in</th>
                          <th className={thClass}>Dias sem Contato</th>
                          <th className={`${thClass} text-center`}>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {clients.filter(c => c.status === "Ativo").map((client) => {
                          const lastCheckin = client.last_checkin ? new Date(client.last_checkin) : null;
                          const daysSince = lastCheckin ? Math.floor((Date.now() - lastCheckin.getTime()) / 86400000) : null;
                          const isOverdue = daysSince !== null && daysSince > 15;
                          const neverContacted = daysSince === null;
                          return (
                            <tr key={client.id} className={`border-b border-gold/5 transition-colors ${isOverdue || neverContacted ? "bg-red-500/5" : "hover:bg-secondary/20"}`}>
                              <td className="px-5 py-4 font-body text-sm text-champagne/80">{client.name}</td>
                              <td className="px-5 py-4 font-body text-xs text-champagne/45">{client.service}</td>
                              <td className="px-5 py-4 font-body text-xs text-champagne/50">
                                {lastCheckin ? lastCheckin.toLocaleDateString("pt-BR") : <span className="text-red-400/60">Nunca</span>}
                              </td>
                              <td className={`px-5 py-4 font-body text-sm font-medium ${isOverdue ? "text-red-400" : neverContacted ? "text-red-400/60" : daysSince !== null && daysSince > 10 ? "text-gold" : "text-green-400"}`}>
                                {daysSince !== null ? `${daysSince}d` : "—"}
                              </td>
                              <td className="px-5 py-4 text-center">
                                <span className={`font-body text-[9px] tracking-wider px-2.5 py-0.5 rounded-full ${
                                  isOverdue || neverContacted
                                    ? "bg-red-500/15 text-red-400"
                                    : daysSince !== null && daysSince > 10
                                    ? "bg-gold/15 text-gold"
                                    : "bg-green-500/10 text-green-400"
                                }`}>
                                  {isOverdue ? "Atrasado" : neverContacted ? "Sem registro" : daysSince !== null && daysSince > 10 ? "Atenção" : "OK"}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}


          {/* === GESTÃO DE ACESSOS === */}
          {activeTab === "access" && (
            <div className="space-y-8">
              <div className="border border-gold/15 p-6 md:p-8">
                <div className="flex items-center gap-2.5 mb-6">
                  <UserPlus className="w-4 h-4 text-gold/60" />
                  <h3 className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/50">Criar Acesso de Cliente</h3>
                </div>

                {accessMsg && (
                  <div className={`mb-6 p-4 border rounded-sm flex items-center gap-2.5 ${accessMsg.type === "success" ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                    <CheckCircle className={`w-4 h-4 shrink-0 ${accessMsg.type === "success" ? "text-green-400" : "text-red-400"}`} />
                    <p className={`font-body text-xs ${accessMsg.type === "success" ? "text-green-400" : "text-red-400"}`}>{accessMsg.text}</p>
                  </div>
                )}

                <form onSubmit={handleCreateClientUser} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                  <div>
                    <label className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30 mb-1.5 block">Cliente</label>
                    <select
                      value={accessFormClient}
                      onChange={(e) => setAccessFormClient(e.target.value)}
                      required
                      className="w-full bg-transparent border border-gold/20 rounded-sm px-3 py-2.5 font-body text-xs text-champagne/80 focus:outline-none focus:border-gold/50 transition-colors"
                    >
                      <option value="" className="bg-background">Selecione...</option>
                      {clients.map((c) => (
                        <option key={c.id} value={c.id} className="bg-background">{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30 mb-1.5 block">E-mail do Cliente</label>
                    <input
                      type="email"
                      value={accessFormEmail}
                      onChange={(e) => setAccessFormEmail(e.target.value)}
                      placeholder="cliente@email.com"
                      required
                      className="w-full bg-transparent border border-gold/20 rounded-sm px-3 py-2.5 font-body text-xs text-champagne/80 placeholder:text-champagne/15 focus:outline-none focus:border-gold/50 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30 mb-1.5 block">Senha Provisória</label>
                    <input
                      type="text"
                      value={accessFormPassword}
                      onChange={(e) => setAccessFormPassword(e.target.value)}
                      placeholder="Min. 6 caracteres"
                      required
                      minLength={6}
                      className="w-full bg-transparent border border-gold/20 rounded-sm px-3 py-2.5 font-body text-xs text-champagne/80 placeholder:text-champagne/15 focus:outline-none focus:border-gold/50 transition-colors"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={accessLoading}
                    className="font-body text-[10px] tracking-[0.2em] uppercase bg-gold text-background py-2.5 px-5 rounded-sm hover:bg-champagne transition-colors font-semibold disabled:opacity-50"
                  >
                    {accessLoading ? "Criando..." : "Criar Acesso"}
                  </button>
                </form>
              </div>

              <div className="border border-gold/15">
                <div className="px-5 md:px-6 py-4 border-b border-gold/10 flex items-center gap-2.5">
                  <KeyRound className="w-4 h-4 text-gold/40" />
                  <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40">Clientes com Acesso ao Portal</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[500px]">
                    <thead>
                      <tr className="border-b border-gold/10">
                        <th className={thClass}>Cliente</th>
                        <th className={thClass}>E-mail</th>
                        <th className={`${thClass} text-right`}>Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {accessProfiles.length === 0 ? (
                        <tr>
                          <td colSpan={3} className="px-5 py-10 text-center">
                            <p className="font-body text-xs text-champagne/25">Nenhum acesso cadastrado ainda.</p>
                          </td>
                        </tr>
                      ) : (
                        accessProfiles.map((p) => {
                          const clientName = clients.find((c) => c.id === p.client_id)?.name || "—";
                          return (
                            <tr key={p.user_id} className="border-b border-gold/5 hover:bg-secondary/20 transition-colors">
                              <td className="px-5 py-4 font-body text-sm text-champagne/80">{clientName}</td>
                              <td className="px-5 py-4 font-body text-xs text-champagne/50">{p.email}</td>
                              <td className="px-5 py-4 text-right">
                                <div className="flex items-center justify-end gap-2">
                                  {resetPasswordUserId === p.user_id ? (
                                    <div className="flex items-center gap-2">
                                      <input
                                        type="text"
                                        value={resetPasswordValue}
                                        onChange={(e) => setResetPasswordValue(e.target.value)}
                                        placeholder="Nova senha"
                                        className="bg-transparent border border-gold/20 rounded-sm px-2 py-1 font-body text-xs text-champagne/80 w-32 focus:outline-none focus:border-gold/50"
                                      />
                                      <button
                                        onClick={() => handleResetPassword(p.user_id)}
                                        disabled={accessLoading}
                                        className="font-body text-[9px] tracking-wider text-green-400 hover:text-green-300"
                                      >
                                        OK
                                      </button>
                                      <button
                                        onClick={() => { setResetPasswordUserId(null); setResetPasswordValue(""); }}
                                        className="font-body text-[9px] tracking-wider text-champagne/30 hover:text-champagne/50"
                                      >
                                        ✕
                                      </button>
                                    </div>
                                  ) : (
                                    <button
                                      onClick={() => setResetPasswordUserId(p.user_id)}
                                      className="flex items-center gap-1 font-body text-[9px] tracking-wider text-gold/50 hover:text-gold transition-colors"
                                      title="Resetar Senha"
                                    >
                                      <RotateCcw className="w-3 h-3" />
                                      <span className="hidden md:inline">Resetar</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => handleDeleteAccess(p.user_id)}
                                    className="flex items-center gap-1 font-body text-[9px] tracking-wider text-red-400/50 hover:text-red-400 transition-colors"
                                    title="Remover Acesso"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                    <span className="hidden md:inline">Remover</span>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}


          {activeTab === "ai" && (
            <div className="border border-gold/15 p-10 text-center">
              <Bot className="w-12 h-12 text-gold/20 mx-auto mb-4" />
              <h3 className="font-display text-lg text-champagne/60 editorial-spacing mb-2">IA & Automações</h3>
              <p className="font-body text-xs text-champagne/30 max-w-md mx-auto">
                Seção em construção. Em breve: métricas de agentes de IA, automações de WhatsApp, taxa de qualificação e performance dos SDRs digitais.
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
