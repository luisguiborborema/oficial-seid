import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import logoSeid from "@/assets/logo-seid.png";

const AdminLogin = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (authError) {
      setError("Credenciais inválidas. Tente novamente.");
      return;
    }
    navigate("/admin-seid");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-5">
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <img src={logoSeid} alt="SEID" className="h-8 object-contain mx-auto mb-6" />
          <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/50">
            Painel Administrativo
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="font-body text-[10px] tracking-[0.2em] uppercase text-champagne/40 mb-2 block">
              E-mail
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-transparent border-b border-gold/30 py-3 font-body text-sm text-champagne placeholder:text-champagne/20 focus:outline-none focus:border-gold transition-colors"
              placeholder="admin@seid.com.br"
              required
            />
          </div>
          <div>
            <label className="font-body text-[10px] tracking-[0.2em] uppercase text-champagne/40 mb-2 block">
              Senha
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-transparent border-b border-gold/30 py-3 font-body text-sm text-champagne placeholder:text-champagne/20 focus:outline-none focus:border-gold transition-colors"
              placeholder="••••••••"
              required
            />
          </div>

          {error && (
            <p className="font-body text-xs text-red-400 text-center">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full font-body text-xs tracking-[0.3em] uppercase bg-gold text-background py-3.5 rounded-full hover:bg-champagne transition-colors duration-500 font-semibold disabled:opacity-50"
          >
            {loading ? "Entrando..." : "Acessar Painel"}
          </button>
        </form>

        <div className="mt-6 flex items-center gap-3">
          <div className="flex-1 h-px bg-gold/20" />
          <span className="font-body text-[9px] tracking-[0.2em] uppercase text-champagne/30">ou</span>
          <div className="flex-1 h-px bg-gold/20" />
        </div>

        <button
          onClick={async () => {
            const { error } = await lovable.auth.signInWithOAuth("google", {
              redirect_uri: window.location.origin,
            });
            if (error) setError("Erro ao conectar com Google.");
          }}
          className="mt-4 w-full flex items-center justify-center gap-2.5 border border-gold/20 py-3 rounded-full hover:border-gold/50 transition-colors duration-500"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          <span className="font-body text-[10px] tracking-[0.2em] uppercase text-champagne/70">Entrar com Google</span>
        </button>
      </div>
    </div>
  );
};

export default AdminLogin;
