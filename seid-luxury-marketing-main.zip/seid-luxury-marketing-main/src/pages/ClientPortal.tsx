import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import logoSeid from "@/assets/logo-seid.png";
import {
  BarChart3, FolderOpen, Cpu, FileText, LogOut, TrendingUp, TrendingDown, Minus,
  Video, FileSignature, Palette, ExternalLink, Zap, CheckCircle, AlertCircle,
  LayoutDashboard, Menu, X
} from "lucide-react";

type Tab = "dashboard" | "files" | "automation" | "reports";

const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Visão Geral", icon: LayoutDashboard },
  { id: "files", label: "Arquivos", icon: FolderOpen },
  { id: "automation", label: "Automação", icon: Cpu },
  { id: "reports", label: "Relatórios", icon: FileText },
];

const fileCategoryIcons: Record<string, React.ElementType> = {
  Criativos: Palette,
  Vídeos: Video,
  Contratos: FileSignature,
};

const ClientPortal = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [clientName, setClientName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [clientData, setClientData] = useState<any>(null);
  const [metrics, setMetrics] = useState<any[]>([]);
  const [files, setFiles] = useState<any[]>([]);
  const [automations, setAutomations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/portal-cliente/login");
        return;
      }
      setUserEmail(session.user.email || "");

      // Get client profile
      const { data: profile } = await supabase
        .from("client_profiles")
        .select("client_id")
        .eq("user_id", session.user.id)
        .maybeSingle();

      if (!profile) {
        navigate("/portal-cliente/login");
        return;
      }

      // Fetch client data
      const { data: client } = await supabase
        .from("admin_clients")
        .select("*")
        .eq("id", profile.client_id)
        .maybeSingle();

      if (client) {
        setClientData(client);
        setClientName(client.name);
      }

      // Fetch metrics
      const { data: metricsData } = await supabase
        .from("admin_performance_metrics")
        .select("*")
        .eq("client_id", profile.client_id)
        .order("period_date", { ascending: false });

      if (metricsData) setMetrics(metricsData);

      // Fetch files
      const { data: filesData } = await supabase
        .from("client_files")
        .select("*")
        .eq("client_id", profile.client_id)
        .order("created_at", { ascending: false });

      if (filesData) setFiles(filesData);

      // Fetch automations
      const { data: autoData } = await supabase
        .from("client_automations")
        .select("*")
        .eq("client_id", profile.client_id);

      if (autoData) setAutomations(autoData);

      setLoading(false);
    };

    checkAuth();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/portal-cliente/login");
  };

  const kpis = useMemo(() => {
    const now = new Date();
    const thisMonth = metrics.filter(m => {
      const d = new Date(m.period_date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    });

    const totalLeads = thisMonth.reduce((s, m) => s + (m.leads_generated || 0), 0);
    const totalSpend = thisMonth.reduce((s, m) => s + Number(m.ad_spend || 0), 0);
    const totalRevenue = thisMonth.reduce((s, m) => s + Number(m.revenue_generated || 0), 0);
    const cpl = totalLeads > 0 ? totalSpend / totalLeads : 0;
    const roi = totalSpend > 0 ? ((totalRevenue - totalSpend) / totalSpend) * 100 : 0;

    return { totalLeads, cpl, roi };
  }, [metrics]);

  const TrendIcon = ({ value }: { value: number }) => {
    if (value > 0) return <TrendingUp className="w-4 h-4 text-emerald-400" />;
    if (value < 0) return <TrendingDown className="w-4 h-4 text-red-400" />;
    return <Minus className="w-4 h-4 text-gold" />;
  };

  const filesByCategory = useMemo(() => {
    const cats: Record<string, typeof files> = {};
    files.forEach(f => {
      if (!cats[f.category]) cats[f.category] = [];
      cats[f.category].push(f);
    });
    return cats;
  }, [files]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <img src={logoSeid} alt="SEID" className="h-6 mx-auto mb-4 opacity-50" />
          <p className="font-body text-[10px] tracking-[0.3em] uppercase text-muted-foreground">
            Carregando...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-gold/10 px-4 md:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src={logoSeid} alt="SEID" className="h-5 object-contain" />
            <div className="hidden md:block h-4 w-px bg-gold/20" />
            <p className="hidden md:block font-body text-[10px] tracking-[0.2em] uppercase text-muted-foreground">
              Portal do Cliente
            </p>
          </div>

          <div className="flex items-center gap-4">
            <p className="hidden md:block font-body text-xs text-champagne/70">
              {clientName}
            </p>
            <button
              onClick={handleLogout}
              className="font-body text-[10px] tracking-[0.15em] uppercase text-muted-foreground hover:text-champagne transition-colors flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Sair</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-champagne"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-6">
        {/* Tab Navigation */}
        <nav className={`${mobileMenuOpen ? "block" : "hidden"} md:block mb-8`}>
          <div className="flex flex-col md:flex-row gap-1 md:gap-0 md:border-b border-gold/10">
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => { setActiveTab(tab.id); setMobileMenuOpen(false); }}
                  className={`flex items-center gap-2 px-4 py-3 font-body text-[11px] tracking-[0.15em] uppercase transition-colors border-b-2 ${
                    isActive
                      ? "border-gold text-gold"
                      : "border-transparent text-muted-foreground hover:text-champagne"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            <div>
              <h1 className="font-display text-xl md:text-2xl text-champagne mb-1">
                Bem-vindo, {clientName}
              </h1>
              <p className="font-body text-xs text-muted-foreground">
                Resumo de performance do mês atual
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Leads */}
              <div className="bg-card rounded-lg p-6 border border-gold/10">
                <div className="flex items-center justify-between mb-4">
                  <p className="font-body text-[10px] tracking-[0.2em] uppercase text-muted-foreground">
                    Leads Gerados
                  </p>
                  <BarChart3 className="w-4 h-4 text-gold/40" />
                </div>
                <div className="flex items-end gap-3">
                  <p className="font-display text-3xl text-champagne">{kpis.totalLeads}</p>
                  <TrendIcon value={kpis.totalLeads} />
                </div>
                <p className="font-body text-[10px] text-muted-foreground mt-2">Este mês</p>
              </div>

              {/* CPL */}
              <div className="bg-card rounded-lg p-6 border border-gold/10">
                <div className="flex items-center justify-between mb-4">
                  <p className="font-body text-[10px] tracking-[0.2em] uppercase text-muted-foreground">
                    Custo por Lead
                  </p>
                  <TrendingDown className="w-4 h-4 text-gold/40" />
                </div>
                <div className="flex items-end gap-3">
                  <p className="font-display text-3xl text-champagne">
                    R$ {kpis.cpl.toFixed(2)}
                  </p>
                  <TrendIcon value={kpis.cpl > 0 ? -1 : 0} />
                </div>
                <p className="font-body text-[10px] text-muted-foreground mt-2">Média mensal</p>
              </div>

              {/* ROI */}
              <div className="bg-card rounded-lg p-6 border border-gold/10">
                <div className="flex items-center justify-between mb-4">
                  <p className="font-body text-[10px] tracking-[0.2em] uppercase text-muted-foreground">
                    ROI
                  </p>
                  <TrendingUp className="w-4 h-4 text-gold/40" />
                </div>
                <div className="flex items-end gap-3">
                  <p className={`font-display text-3xl ${kpis.roi >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {kpis.roi.toFixed(0)}%
                  </p>
                  <TrendIcon value={kpis.roi} />
                </div>
                <p className="font-body text-[10px] text-muted-foreground mt-2">Retorno sobre investimento</p>
              </div>
            </div>

            {/* Service info */}
            {clientData && (
              <div className="bg-card rounded-lg p-6 border border-gold/10">
                <p className="font-body text-[10px] tracking-[0.2em] uppercase text-muted-foreground mb-3">
                  Seu Plano
                </p>
                <div className="flex flex-wrap gap-4">
                  <div>
                    <p className="font-body text-xs text-muted-foreground">Serviço</p>
                    <p className="font-display text-sm text-champagne">{clientData.service}</p>
                  </div>
                  <div className="h-8 w-px bg-gold/10 hidden md:block" />
                  <div>
                    <p className="font-body text-xs text-muted-foreground">Campanha</p>
                    <span className={`inline-flex items-center gap-1.5 font-body text-xs px-2.5 py-0.5 rounded-full ${
                      clientData.campaign_status === "Ativa"
                        ? "bg-emerald-500/10 text-emerald-400"
                        : "bg-red-500/10 text-red-400"
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        clientData.campaign_status === "Ativa" ? "bg-emerald-400" : "bg-red-400"
                      }`} />
                      {clientData.campaign_status}
                    </span>
                  </div>
                  {clientData.next_billing && (
                    <>
                      <div className="h-8 w-px bg-gold/10 hidden md:block" />
                      <div>
                        <p className="font-body text-xs text-muted-foreground">Próxima Renovação</p>
                        <p className="font-display text-sm text-champagne">
                          {new Date(clientData.next_billing).toLocaleDateString("pt-BR")}
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Files Tab */}
        {activeTab === "files" && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-xl text-champagne mb-1">Central de Arquivos</h2>
              <p className="font-body text-xs text-muted-foreground">
                Acesse seus criativos, vídeos e documentos
              </p>
            </div>

            {Object.keys(filesByCategory).length === 0 ? (
              <div className="bg-card rounded-lg p-12 border border-gold/10 text-center">
                <FolderOpen className="w-8 h-8 text-gold/30 mx-auto mb-3" />
                <p className="font-body text-sm text-muted-foreground">
                  Nenhum arquivo disponível ainda
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Object.entries(filesByCategory).map(([category, categoryFiles]) => {
                  const Icon = fileCategoryIcons[category] || FolderOpen;
                  return (
                    <div key={category} className="bg-card rounded-lg p-6 border border-gold/10">
                      <div className="flex items-center gap-2.5 mb-4">
                        <div className="w-8 h-8 rounded-md bg-secondary flex items-center justify-center">
                          <Icon className="w-4 h-4 text-gold" />
                        </div>
                        <p className="font-body text-[11px] tracking-[0.15em] uppercase text-champagne">
                          {category}
                        </p>
                      </div>
                      <div className="space-y-2">
                        {categoryFiles.map(file => (
                          <a
                            key={file.id}
                            href={file.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-between py-2 px-3 rounded-md hover:bg-secondary/50 transition-colors group"
                          >
                            <span className="font-body text-xs text-champagne/80 group-hover:text-champagne truncate">
                              {file.label}
                            </span>
                            <ExternalLink className="w-3 h-3 text-gold/40 group-hover:text-gold flex-shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Automation Tab */}
        {activeTab === "automation" && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-xl text-champagne mb-1">Centro de Operações</h2>
              <p className="font-body text-xs text-muted-foreground">
                Status das suas automações e agentes de IA
              </p>
            </div>

            {automations.length === 0 ? (
              <div className="bg-card rounded-lg p-12 border border-gold/10 text-center">
                <Cpu className="w-8 h-8 text-gold/30 mx-auto mb-3" />
                <p className="font-body text-sm text-muted-foreground">
                  Nenhuma automação configurada
                </p>
                <p className="font-body text-[10px] text-muted-foreground mt-1">
                  Contrate o Piloto Automático ou Agentes de IA para ativar
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {automations.map(auto => (
                  <div key={auto.id} className="bg-card rounded-lg p-6 border border-gold/10">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-md flex items-center justify-center ${
                          auto.status === "Ativa" ? "bg-emerald-500/10" : "bg-red-500/10"
                        }`}>
                          {auto.status === "Ativa"
                            ? <Zap className="w-4 h-4 text-emerald-400" />
                            : <AlertCircle className="w-4 h-4 text-red-400" />
                          }
                        </div>
                        <div>
                          <p className="font-body text-sm text-champagne">{auto.automation_name}</p>
                          {auto.description && (
                            <p className="font-body text-[10px] text-muted-foreground mt-0.5">
                              {auto.description}
                            </p>
                          )}
                        </div>
                      </div>
                      <span className={`inline-flex items-center gap-1.5 font-body text-[10px] px-2.5 py-1 rounded-full ${
                        auto.status === "Ativa"
                          ? "bg-emerald-500/10 text-emerald-400"
                          : "bg-red-500/10 text-red-400"
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                          auto.status === "Ativa" ? "bg-emerald-400" : "bg-red-400"
                        }`} />
                        {auto.status}
                      </span>
                    </div>
                    {auto.status === "Ativa" && (
                      <div className="flex items-center gap-1.5 mt-4 pt-3 border-t border-gold/5">
                        <CheckCircle className="w-3 h-3 text-emerald-400" />
                        <p className="font-body text-[10px] text-emerald-400/70">
                          Sistema de Resposta Online
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Reports Tab */}
        {activeTab === "reports" && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-xl text-champagne mb-1">Relatórios</h2>
              <p className="font-body text-xs text-muted-foreground">
                Dashboard exclusivo de performance
              </p>
            </div>

            {clientData?.looker_studio_url ? (
              <div className="bg-card rounded-lg border border-gold/10 overflow-hidden">
                <iframe
                  src={(() => {
                    const base = clientData.looker_studio_url;
                    const separator = base.includes("?") ? "&" : "?";
                    const params = encodeURIComponent(JSON.stringify({ "ds0.email_cliente": userEmail }));
                    return `${base}${separator}params=${params}`;
                  })()}
                  className="w-full h-[600px] md:h-[800px]"
                  frameBorder="0"
                  allowFullScreen
                  title="Relatório de Performance"
                />
              </div>
            ) : (
              <div className="bg-card rounded-lg p-12 border border-gold/10 text-center">
                <FileText className="w-8 h-8 text-gold/30 mx-auto mb-3" />
                <p className="font-body text-sm text-muted-foreground">
                  Relatório em preparação
                </p>
                <p className="font-body text-[10px] text-muted-foreground mt-1">
                  Seu dashboard personalizado será configurado em breve
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientPortal;
