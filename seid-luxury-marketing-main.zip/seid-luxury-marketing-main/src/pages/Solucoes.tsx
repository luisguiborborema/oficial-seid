import { motion, useInView, AnimatePresence } from "framer-motion";
import { useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { X } from "lucide-react";
import logoSeid from "@/assets/logo-seid.png";
import Footer from "@/components/Footer";
import EngenhariaSeid from "@/components/EngenhariaSeid";
import ExperienciaCliente from "@/components/ExperienciaCliente";
import {
  Compass,
  Fingerprint,
  LayoutGrid,
  Video,
  Rocket,
  Bot,
  Camera,
  Globe,
  BrainCircuit,
  BarChartBig,
  ShieldCheck,
  ArrowRight,
  ChevronRight,
} from "lucide-react";

const services = [
  {
    step: "01",
    label: "Diagnóstico",
    icon: Compass,
    title: "Consultoria Estratégica",
    tagline: "O ponto de virada para sua marca.",
    description:
      "Antes de executar, entendemos o cenário completo. Analisamos sua presença digital, concorrência e oportunidades para construir um plano de ação claro e mensurável.",
    includes: [
      "Mapa mental pós-reunião com plano tático",
      "Análise completa de presença digital",
      "Diagnóstico de posicionamento e concorrência",
    ],
  },
  {
    step: "02",
    label: "Identidade",
    icon: Fingerprint,
    title: "DNA Digital",
    tagline: "Você não é só um corretor, é uma marca.",
    description:
      "Definimos quem você é no digital. Do arquétipo ao tom de voz, criamos um posicionamento autêntico que diferencia você no mercado e gera conexão real.",
    includes: [
      "Definição de arquétipos e personalidade de marca",
      "Tom de voz e diretrizes de comunicação",
      "Guia de estilo visual completo",
    ],
  },
  {
    step: "03",
    label: "Presença",
    icon: LayoutGrid,
    title: "Vitrine Impactante",
    tagline: "Sua vitrine digital com constância.",
    description:
      "Gestão completa de redes sociais com conteúdo estratégico que constrói autoridade e mantém sua marca viva e relevante todos os dias.",
    includes: [
      "Planejamento editorial mensal",
      "Criação de artes e design de posts",
      "Legendas persuasivas e agendamento",
    ],
  },
  {
    step: "04",
    label: "Qualificação",
    icon: Video,
    title: "Vendedor Invisível",
    tagline: "Um funil de perfil que qualifica leads 24/7.",
    description:
      "Sistema de vídeos fixados estrategicamente no seu perfil que educam, qualificam e convertem visitantes em leads prontos para comprar — mesmo enquanto você dorme.",
    includes: [
      "Roteirização de vídeo: Quem é você",
      "Roteirização de vídeo: O que você oferece",
      "Roteirização de vídeo: Experiência e prova social",
    ],
  },
  {
    step: "05",
    label: "Audiovisual",
    icon: Camera,
    title: "Imersão Visual",
    tagline: "Seus imóveis vão parar de parecer anúncio — e vão virar desejo.",
    description:
      "Produção de vídeos e fotos com estética cinematográfica e narrativa de venda. Não é apenas 'mostrar', é criar uma experiência visual que encanta e converte.",
    includes: [
      "Roteirização e direção de cena",
      "Captação profissional de vídeo e foto",
      "Edição dinâmica com legendas persuasivas",
      "Entrega organizada via Drive",
    ],
  },
  {
    step: "06",
    label: "Digital",
    icon: Globe,
    title: "Presença Digital Sólida",
    tagline: "Sua autoridade merece uma casa própria no digital.",
    description:
      "Desenvolvimento de Landing Pages de alta conversão e Sites Institucionais focados em fortalecimento de marca e geração de leads. Design editorial alinhado à identidade SEID, alta velocidade de carregamento e foco total na jornada do cliente imobiliário.",
    includes: [
      "Landing Pages de alta conversão",
      "Sites institucionais com design editorial",
      "Otimização de velocidade e SEO",
      "Foco na jornada do cliente imobiliário",
    ],
  },
  {
    step: "07",
    label: "Escala",
    icon: Rocket,
    title: "Motor de Leads",
    tagline: "Tráfego pago com inteligência e método.",
    description:
      "Gestão de Meta Ads com estratégia de funil completa. Do criativo ao relatório, cada centavo investido é rastreado e otimizado para gerar leads qualificados.",
    includes: [
      "Estratégia de funil e segmentação",
      "Criação de criativos e copy de alta conversão",
      "Testes A/B e relatórios mensais detalhados",
    ],
  },
  {
    step: "08",
    label: "Automação",
    icon: Bot,
    title: "Piloto Automático",
    tagline: "Engenharia de atendimento que não dorme.",
    description:
      "Automação inteligente de WhatsApp que responde, qualifica e direciona leads automaticamente. Atendimento profissional 24 horas por dia, 7 dias por semana.",
    includes: [
      "Fluxos inteligentes de WhatsApp",
      "Integração direta com anúncios",
      "Roteiros de resposta personalizados",
    ],
    note: "Modelo comercial: Setup + Mensalidade (manutenção e hospedagem)",
  },
  {
    step: "09",
    label: "Inteligência",
    icon: BrainCircuit,
    title: "Cérebro Digital",
    tagline: "Sua equipe de elite operando 24/7 com inteligência artificial.",
    description:
      "Desenvolvimento de agentes de IA personalizados que atuam como SDRs. Eles qualificam leads, respondem dúvidas complexas com seu tom de voz e agendam visitas em tempo real, sem que você precise tocar no celular.",
    includes: [
      "Treinamento da IA com sua base de conhecimento",
      "Integração com WhatsApp e Instagram",
      "Fluxo de transição para o humano nos leads quentes",
      "Qualificação e agendamento automático",
    ],
  },
  {
    step: "10",
    label: "Performance",
    icon: BarChartBig,
    title: "Inteligência de Dados & CRM",
    tagline: "Decisões baseadas em números, não em achismos.",
    description:
      "Implementação e organização de funis no CRM integrados ao marketing. Criamos painéis de controle para você visualizar de onde vêm seus melhores leads e qual o seu real ROI.",
    includes: [
      "Configuração de esteira de vendas no CRM",
      "Automação de status de lead",
      "Relatórios de performance mensais",
      "Dashboards de ROI e origem de leads",
    ],
  },
];

const ServiceCard = ({
  service,
  index,
  isInView,
}: {
  service: (typeof services)[0];
  index: number;
  isInView: boolean;
}) => {
  const Icon = service.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay: 0.15 * index }}
      className="border border-gold/20 hover:border-gold/50 transition-all duration-500 group"
    >
      {/* Step indicator */}
      <div className="flex items-center gap-3 px-8 pt-8 mb-6">
        <span className="font-body text-[10px] tracking-[0.4em] uppercase text-gold/40">
          Etapa {service.step}
        </span>
        <div className="gold-line flex-1 opacity-20" />
        <span className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/60">
          {service.label}
        </span>
      </div>

      <div className="px-8 pb-8">
        {/* Icon & Title */}
        <div className="flex items-start gap-5 mb-5">
          <div className="w-12 h-12 flex items-center justify-center border border-gold/20 rounded-full shrink-0 group-hover:border-gold/50 transition-colors">
            <Icon className="w-5 h-5 text-gold opacity-70 group-hover:opacity-100 transition-opacity" />
          </div>
          <div>
            <h3 className="font-display text-xl text-champagne editorial-spacing mb-1">
              {service.title}
            </h3>
            <p className="font-display text-sm italic text-gold/70">
              {service.tagline}
            </p>
          </div>
        </div>

        {/* Description */}
        <p className="font-body text-sm text-champagne/55 leading-relaxed font-light mb-6">
          {service.description}
        </p>

        {/* Includes */}
        <div className="mb-6">
          <p className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/40 mb-3">
            Inclui
          </p>
          <ul className="space-y-2">
            {service.includes.map((item) => (
              <li key={item} className="flex items-start gap-3">
                <ChevronRight className="w-3 h-3 text-gold/40 mt-1 shrink-0" />
                <span className="font-body text-xs text-champagne/50 font-light leading-relaxed">
                  {item}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Note if exists */}
        {service.note && (
          <div className="border-t border-gold/10 pt-4 mb-6">
            <p className="font-body text-[10px] tracking-wider text-gold/50 italic">
              {service.note}
            </p>
          </div>
        )}

        {/* CTA */}
        <a
          href="/#diagnostico"
          className="inline-flex items-center gap-2 font-body text-xs tracking-[0.2em] uppercase text-gold hover:text-champagne transition-colors duration-300 group/btn"
        >
          Solicitar este serviço
          <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
        </a>
      </div>
    </motion.div>
  );
};

const Solucoes = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const contractRef = useRef(null);
  const contractInView = useInView(contractRef, { once: true, margin: "-50px" });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <main className="overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-5 md:px-16 h-[72px] md:h-auto md:py-6 bg-background/90 backdrop-blur-sm border-b border-gold/10">
        <Link to="/">
          <img src={logoSeid} alt="SEID" className="h-7 md:h-9 object-contain" />
        </Link>

        {/* Hamburger - mobile */}
        <button
          onClick={() => setMobileMenuOpen(true)}
          className="md:hidden flex flex-col gap-[5px] p-2"
          aria-label="Abrir menu"
        >
          <span className="block w-5 h-[1px] bg-champagne/70" />
          <span className="block w-5 h-[1px] bg-champagne/70" />
          <span className="block w-5 h-[1px] bg-champagne/70" />
        </button>

        <div className="hidden md:flex items-center gap-8 font-body text-xs tracking-widest uppercase text-champagne/60">
          <Link to="/" className="hover:text-gold transition-colors duration-300">
            Home
          </Link>
          <a href="#servicos" className="hover:text-gold transition-colors duration-300">
            Serviços
          </a>
          <a href="/#diagnostico" className="hover:text-gold transition-colors duration-300">
            Contato
          </a>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-[60] bg-background flex flex-col"
          >
            <div className="flex items-center justify-between px-5 h-[72px]">
              <Link to="/">
                <img src={logoSeid} alt="SEID" className="h-7 object-contain" />
              </Link>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="text-champagne/70 hover:text-gold transition-colors duration-300 p-2"
                aria-label="Fechar menu"
              >
                <X className="w-6 h-6" strokeWidth={1.5} />
              </button>
            </div>
            <nav className="flex-1 flex flex-col items-center justify-center gap-8">
              {[
                { label: "Home", href: "/" },
                { label: "Serviços", href: "#servicos" },
                { label: "Contato", href: "/#diagnostico" },
              ].map((link) => (
                <motion.button
                  key={link.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.1 }}
                  onClick={() => {
                    setMobileMenuOpen(false);
                    if (link.href.startsWith("/#")) {
                      navigate(link.href);
                    } else if (link.href.startsWith("#")) {
                      setTimeout(() => {
                        document.querySelector(link.href)?.scrollIntoView({ behavior: "smooth" });
                      }, 300);
                    } else {
                      navigate(link.href);
                    }
                  }}
                  className="font-display text-2xl tracking-widest uppercase text-champagne/80 hover:text-gold transition-colors duration-300"
                >
                  {link.label}
                </motion.button>
              ))}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.3 }}
                className="mt-8"
              >
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    navigate("/#diagnostico");
                  }}
                  className="font-body text-sm tracking-[0.3em] uppercase bg-gold text-background px-10 py-4 rounded-full hover:bg-champagne transition-colors duration-500 font-semibold"
                >
                  Solicitar Diagnóstico
                </button>
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero */}
      <section className="pt-40 pb-24 md:pb-32 bg-background">
        <div className="max-w-4xl mx-auto px-8 text-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <p className="font-body text-xs tracking-[0.4em] uppercase text-gold mb-6">
              Nossas Soluções
            </p>
            <div className="gold-line w-12 mx-auto mb-10" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="font-display text-4xl md:text-5xl lg:text-6xl text-champagne editorial-spacing mb-8"
          >
            Do diagnóstico à escala.{" "}
            <span className="italic text-gold">Uma jornada completa.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="font-body text-base md:text-lg text-champagne/55 max-w-2xl mx-auto leading-relaxed font-light"
          >
            Cada serviço é uma etapa de evolução. Não vendemos peças soltas —
            construímos um sistema integrado de marketing que cresce com você.
          </motion.p>
        </div>
      </section>

      {/* Journey line */}
      <div className="bg-background">
        <div className="max-w-6xl mx-auto px-8 flex items-center gap-3">
          <span className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/30">
            Diagnóstico
          </span>
          <div className="gold-line flex-1 opacity-15" />
          <span className="font-body text-[10px] tracking-[0.3em] uppercase text-gold/30">
            Escala
          </span>
        </div>
      </div>

      {/* Services Grid */}
      <section id="servicos" ref={ref} className="py-20 md:py-28 bg-background">
        <div className="max-w-6xl mx-auto px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={service.step}
                service={service}
                index={index}
                isInView={isInView}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Contract / Trust Section */}
      <section ref={contractRef} className="py-20 md:py-28 bg-petrol-light texture-linen">
        <div className="max-w-3xl mx-auto px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={contractInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="border border-gold/30 p-10 md:p-14 text-center"
          >
            <ShieldCheck className="w-10 h-10 text-gold mx-auto mb-6 opacity-70" />
            <p className="font-body text-[10px] tracking-[0.4em] uppercase text-gold/50 mb-4">
              Rigor Técnico
            </p>
            <h2 className="font-display text-2xl md:text-3xl text-champagne editorial-spacing mb-6">
              Transparência e Segurança
            </h2>
            <div className="gold-line w-10 mx-auto mb-8 opacity-50" />
            <p className="font-body text-sm md:text-base text-champagne/60 leading-relaxed font-light max-w-xl mx-auto mb-8">
              Todos os nossos serviços possuem escopo exato definido em contrato — incluindo número de criativos, prazos e plataformas — garantindo proteção jurídica e previsibilidade total para sua empresa.
            </p>
            <a
              href="/#diagnostico"
              className="inline-block font-body text-xs tracking-[0.3em] uppercase border border-gold text-gold px-10 py-4 rounded-full hover:bg-gold hover:text-background transition-all duration-500 font-medium"
            >
              Solicitar Diagnóstico Gratuito
            </a>
          </motion.div>
        </div>
      </section>

      <EngenhariaSeid />
      <ExperienciaCliente />

      <Footer />
    </main>
  );
};

export default Solucoes;
