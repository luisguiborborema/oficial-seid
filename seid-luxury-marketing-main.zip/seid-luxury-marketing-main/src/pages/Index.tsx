import Hero from "@/components/Hero";
import WhyTheyFail from "@/components/WhyTheyFail";
import WhySeid from "@/components/WhySeid";
import CaminhoAutoridade from "@/components/CaminhoAutoridade";
import WhoWeServe from "@/components/WhoWeServe";
import SocialProof from "@/components/SocialProof";
import VideoGallery from "@/components/VideoGallery";
import MarketInsights from "@/components/MarketInsights";
import ImpactTransition from "@/components/ImpactTransition";
import FaqSection from "@/components/FaqSection";
import ClosingBanner from "@/components/ClosingBanner";
import DiagnosticForm from "@/components/DiagnosticForm";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <main className="overflow-x-hidden">
      <Hero />
      <WhyTheyFail />
      <WhySeid />
      <CaminhoAutoridade />
      <WhoWeServe />
      <SocialProof />
      <VideoGallery />
      <MarketInsights />
      <ImpactTransition />
      <FaqSection />
      <ClosingBanner />
      <DiagnosticForm />
      <ContactSection />
      <Footer />
    </main>
  );
};

export default Index;
